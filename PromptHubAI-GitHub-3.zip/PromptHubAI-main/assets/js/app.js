const state = {
  view: 'home',
  prompts: [],
  lessons: [],
  tools: [],
  glossary: [],
  favorites: new Set(),
  search: '',
  category: 'all',
  toolSearch: '',
  toolCategory: 'all',
  glossarySearch: '',
  selectedPromptId: null,
  selectedLessonId: null,
  showAddPromptForm: false,
  theme: localStorage.getItem('promptHubTheme') || 'dark',
  accent: localStorage.getItem('promptHubAccent') || 'nebula',
  loading: true,
  error: null,
};

let installPrompt = null;
let toastTimer = null;

const cache = {
  main: document.getElementById('main-content'),
  toast: document.getElementById('toast'),
  installBtn: document.getElementById('installBtn'),
  themeToggle: document.getElementById('themeToggle'),
  themeToggleIcon: document.getElementById('themeToggleIcon'),
  themeToggleLabel: document.getElementById('themeToggleLabel'),
  sidebar: document.getElementById('sidebar'),
  drawerBackdrop: document.getElementById('drawerBackdrop'),
  drawerOpen: document.getElementById('drawerOpen'),
  drawerClose: document.getElementById('drawerClose'),
  pageTitle: document.getElementById('pageTitle'),
};

const validViews = ['home', 'library', 'learn', 'tools', 'glossary', 'favorites', 'settings', 'about', 'detail', 'lesson'];
const pageTitles = {
  home: 'Home', library: 'Prompt Library', learn: 'Learn AI', tools: 'AI Tools', glossary: 'AI Glossary',
  favorites: 'Favorites', settings: 'Settings', about: 'About', detail: 'Prompt', lesson: 'Lesson',
};

// ---------- Utilities ----------

/** Escape HTML special characters before inserting any data into innerHTML. Prevents XSS. */
function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Delay calling fn until `delay` ms after the last call. Prevents render-per-keystroke thrash. */
function debounce(fn, delay = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// ---------- Init ----------

function init() {
  applyTheme();
  bindSidebarNavigation();
  bindDrawerToggle();
  bindInstall();
  bindThemeToggle();
  bindDelegatedInputs();
  registerServiceWorker();
  cache.main.addEventListener('click', handleMainAction);
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installPrompt = event;
    cache.installBtn.classList.remove('hidden');
  });
  window.addEventListener('popstate', (event) => {
    syncViewFromState(event.state);
    render();
  });
  syncViewFromHash();
  loadData();
}

function bindSidebarNavigation() {
  document.querySelectorAll('.nav-item[data-view]').forEach((button) => {
    button.addEventListener('click', () => {
      navigateTo(button.dataset.view, null);
      closeDrawer();
    });
  });
}

function bindDrawerToggle() {
  cache.drawerOpen.addEventListener('click', openDrawer);
  cache.drawerClose.addEventListener('click', closeDrawer);
  cache.drawerBackdrop.addEventListener('click', closeDrawer);
}

function openDrawer() {
  cache.sidebar.classList.add('open');
  cache.drawerBackdrop.classList.add('open');
}

function closeDrawer() {
  cache.sidebar.classList.remove('open');
  cache.drawerBackdrop.classList.remove('open');
}

function bindInstall() {
  cache.installBtn.addEventListener('click', async () => {
    if (!installPrompt) {
      showToast('Install is not available yet.');
      return;
    }
    installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === 'accepted') {
      showToast('PromptHub AI installed successfully.');
    }
    installPrompt = null;
    cache.installBtn.classList.add('hidden');
  });
}

function bindThemeToggle() {
  cache.themeToggle.addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('promptHubTheme', state.theme);
    applyTheme();
    if (state.view === 'settings') renderSettings();
    showToast(state.theme === 'dark' ? 'Dark mode enabled' : 'Light mode enabled');
  });
}

const DAILY_TIPS = [
  "Give the AI a role before the task — 'You are a senior editor' produces sharper output than a bare instruction.",
  "If the first answer is generic, don't start over — tell the model exactly what's wrong with it and ask it to fix that specific thing.",
  "For anything with steps or tradeoffs, ask the model to 'think step by step before answering' — it measurably improves accuracy.",
  "Show 2-3 examples of the output format you want instead of describing it in words. Examples remove ambiguity that descriptions can't.",
  "Save prompts that worked well as reusable templates with [BRACKETED] placeholders — future you will thank present you.",
  "Ask 'what's the weakest part of this?' after any AI-generated argument or plan — it's the fastest way to stress-test your own thinking.",
  "Long documents? Ask the model to summarize section by section first, then synthesize — it catches details a single pass misses.",
  "Constraints make output better, not worse. Telling the model what to avoid is often more useful than describing what you want.",
];

const DAILY_QUOTES = [
  { text: "The best way to predict the future is to invent it.", author: "Alan Kay" },
  { text: "Any sufficiently advanced technology is indistinguishable from magic.", author: "Arthur C. Clarke" },
  { text: "We are stuck with technology when what we really want is just stuff that works.", author: "Douglas Adams" },
  { text: "The real problem is not whether machines think but whether men do.", author: "B.F. Skinner" },
  { text: "It is not the strongest that survive, but those most responsive to change.", author: "Charles Darwin" },
  { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
  { text: "The people who are crazy enough to think they can change the world are the ones who do.", author: "Steve Jobs" },
];

/** Deterministic pick based on day-of-year so the tip/quote is stable all day and changes daily — no network or server needed. */
function pickForToday(list) {
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000);
  return list[dayOfYear % list.length];
}

const ICONS = {
  moon: '<svg viewBox="0 0 24 24" fill="none"><path d="M20.5 14.5A8.5 8.5 0 1 1 9.5 3.5a7 7 0 0 0 11 11Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="2"/><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none"><path d="m12 17.3-6.16 3.24 1.18-6.86L2 8.76l6.9-1L12 1.5l3.1 6.26 6.9 1-5.02 4.92 1.18 6.86Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
  starFilled: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 17.3-6.16 3.24 1.18-6.86L2 8.76l6.9-1L12 1.5l3.1 6.26 6.9 1-5.02 4.92 1.18 6.86Z"/></svg>',
};

function applyTheme() {
  document.body.classList.toggle('theme-light', state.theme === 'light');
  document.body.classList.remove('accent-ember', 'accent-lagoon');
  if (state.accent === 'ember') document.body.classList.add('accent-ember');
  if (state.accent === 'lagoon') document.body.classList.add('accent-lagoon');
  const isLight = state.theme === 'light';
  cache.themeToggle.setAttribute('aria-pressed', String(isLight));
  cache.themeToggleIcon.innerHTML = isLight ? ICONS.sun : ICONS.moon;
  cache.themeToggleLabel.textContent = isLight ? 'Light mode' : 'Dark mode';
}

function setAccent(accent) {
  state.accent = accent;
  localStorage.setItem('promptHubAccent', accent);
  applyTheme();
  if (state.view === 'settings') renderSettings();
}

/**
 * Single delegated listener for all search inputs, debounced.
 * Attached once at init — never re-attached on render, so no listener leaks.
 */
function bindDelegatedInputs() {
  const debouncedPromptSearch = debounce((value) => {
    state.search = value;
    renderLibrary();
  }, 200);
  const debouncedToolSearch = debounce((value) => {
    state.toolSearch = value;
    renderTools();
  }, 200);
  const debouncedGlossarySearch = debounce((value) => {
    state.glossarySearch = value;
    renderGlossary();
  }, 200);

  cache.main.addEventListener('input', (event) => {
    if (event.target.id === 'promptSearch') debouncedPromptSearch(event.target.value);
    if (event.target.id === 'toolSearch') debouncedToolSearch(event.target.value);
    if (event.target.id === 'glossarySearch') debouncedGlossarySearch(event.target.value);
  });

  cache.main.addEventListener('change', (event) => {
    if (event.target.id === 'importFavorites') importFavorites(event);
  });
}

// ---------- Routing ----------

function navigateTo(view, id = null) {
  state.view = view;
  if (view === 'detail') state.selectedPromptId = id;
  else if (view === 'lesson') state.selectedLessonId = id;
  else { state.selectedPromptId = null; state.selectedLessonId = null; }
  pushHash();
  render();
}

function syncViewFromHash() {
  syncViewFromState(parseHash(window.location.hash));
}

function syncViewFromState(parsed) {
  const data = parsed || parseHash(window.location.hash);
  state.view = data.view;
  state.selectedPromptId = data.promptId ?? null;
  state.selectedLessonId = data.lessonId ?? null;
}

function parseHash(rawHash) {
  const hash = rawHash.replace('#', '').toLowerCase();
  if (hash.startsWith('prompt/')) {
    return { view: 'detail', promptId: Number(hash.split('/')[1]) };
  }
  if (hash.startsWith('lesson/')) {
    return { view: 'lesson', lessonId: Number(hash.split('/')[1]) };
  }
  if (['home', 'library', 'learn', 'tools', 'glossary', 'favorites', 'settings', 'about'].includes(hash)) {
    return { view: hash };
  }
  return { view: 'home' };
}

/** Pushes a new history entry so the browser Back button works correctly between views. */
function pushHash() {
  const nextHash = state.view === 'detail' && state.selectedPromptId
    ? `#prompt/${state.selectedPromptId}`
    : state.view === 'lesson' && state.selectedLessonId
    ? `#lesson/${state.selectedLessonId}`
    : state.view === 'home' ? '' : `#${state.view}`;
  const fullPath = `${window.location.pathname}${nextHash}`;
  if (window.location.hash !== nextHash) {
    history.pushState({ view: state.view, promptId: state.selectedPromptId, lessonId: state.selectedLessonId }, '', fullPath);
  }
}

// ---------- Data loading ----------

/**
 * Data is embedded in assets/js/data.js as PROMPTHUB_DATA (loaded before this script)
 * rather than fetched from separate JSON files. fetch() of local files is blocked by
 * browsers and Android WebView wrappers under the file:// protocol — embedding the
 * data sidesteps that entirely and works identically on web, WebView, and Capacitor.
 */
function loadData() {
  state.loading = true;
  state.error = null;
  render();
  try {
    if (typeof PROMPTHUB_DATA === 'undefined') {
      throw new Error('App data failed to load. Make sure data.js is included before app.js.');
    }
    state.prompts = PROMPTHUB_DATA.prompts;
    state.lessons = PROMPTHUB_DATA.lessons;
    state.tools = PROMPTHUB_DATA.tools;
    state.glossary = PROMPTHUB_DATA.glossary || [];
    const customPrompts = JSON.parse(localStorage.getItem('promptHubCustomPrompts') || '[]');
    state.prompts = [...state.prompts, ...customPrompts];
    const saved = JSON.parse(localStorage.getItem('promptHubFavorites') || '[]');
    state.favorites = new Set(saved);
  } catch (error) {
    state.error = error.message || 'Unable to load PromptHub AI data.';
  } finally {
    state.loading = false;
    render();
  }
}

// ---------- Render dispatch ----------

function render() {
  updateSidebarActive();
  updatePageTitle();
  if (state.loading) {
    renderLoadingSkeleton();
    return;
  }
  if (state.error) {
    renderErrorState();
    return;
  }
  if (state.view === 'detail') return renderDetail();
  if (state.view === 'lesson') return renderLessonDetail();
  if (state.view === 'library') return renderLibrary();
  if (state.view === 'learn') return renderLearn();
  if (state.view === 'tools') return renderTools();
  if (state.view === 'glossary') return renderGlossary();
  if (state.view === 'favorites') return renderFavorites();
  if (state.view === 'settings') return renderSettings();
  if (state.view === 'about') return renderAbout();
  return renderHome();
}

function updatePageTitle() {
  cache.pageTitle.textContent = pageTitles[state.view] || 'PromptHub AI';
}

function renderLoadingSkeleton() {
  const skeletonCard = `
    <div class="skeleton-card">
      <div class="skeleton-line short"></div>
      <div class="skeleton-line long"></div>
      <div class="skeleton-line medium"></div>
    </div>`;
  cache.main.innerHTML = `
    <section class="hero-card">
      <div class="skeleton-line medium"></div>
      <div class="skeleton-line long"></div>
    </section>
    <section class="panel">
      <div class="prompt-grid">
        ${skeletonCard}${skeletonCard}${skeletonCard}
      </div>
    </section>
  `;
}

function renderErrorState() {
  cache.main.innerHTML = `
    <section class="error-card">
      <div class="state-icon error-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/><path d="M12 8v5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="16" r="1" fill="currentColor"/></svg></div>
      <h3>Something went wrong</h3>
      <p>${esc(state.error)}</p>
      <div class="card-actions">
        <button class="primary-btn" data-action="retry" type="button">Try again</button>
      </div>
    </section>
  `;
}

function renderHome() {
  const featured = state.prompts.slice(0, 4);
  const todaysQuote = pickForToday(DAILY_QUOTES);
  cache.main.innerHTML = `
    <section class="hero-card">
      <h2>PromptHub AI is built for modern creators and operators</h2>
      <p>A curated collection of high-quality prompts, real lessons, and a working AI tools directory — organized, saved, and always available offline.</p>
      <div class="hero-actions">
        <button class="primary-btn" data-view="library" type="button">Open prompt library</button>
        <button class="secondary-btn" data-view="learn" type="button">Start learning</button>
      </div>
    </section>

    <section class="stats-grid">
      <div class="stats-card"><strong>${state.prompts.length}</strong><span>prompts</span></div>
      <div class="stats-card"><strong>${state.lessons.length}</strong><span>lessons</span></div>
      <div class="stats-card"><strong>${state.tools.length}</strong><span>AI tools</span></div>
      <div class="stats-card"><strong>${state.favorites.size}</strong><span>favorites</span></div>
    </section>

    <section class="grid-2">
      <div class="detail-card daily-card">
        <span class="tag">💡 Daily AI Tip</span>
        <p>${esc(pickForToday(DAILY_TIPS))}</p>
      </div>
      <div class="detail-card daily-card">
        <span class="tag">✨ Quote of the Day</span>
        <p>“${esc(todaysQuote.text)}”</p>
        <p class="quote-author">— ${esc(todaysQuote.author)}</p>
      </div>
    </section>

    <section class="panel">
      <div class="panel-header">
        <h3>Featured prompts</h3>
        <button class="secondary-btn" data-view="library" type="button">View all</button>
      </div>
      <div class="prompt-grid">
        ${featured.map((prompt) => createPromptCard(prompt, true)).join('')}
      </div>
    </section>

    <section class="panel">
      <div class="panel-header">
        <h3>Learning tracks</h3>
        <button class="secondary-btn" data-view="learn" type="button">Go to Learn AI</button>
      </div>
      <div class="lesson-grid">
        ${state.lessons.slice(0, 3).map((lesson) => createLessonCard(lesson)).join('')}
      </div>
    </section>
  `;
}

function renderLibrary() {
  const query = state.search.toLowerCase();
  const filteredPrompts = state.prompts.filter((prompt) => {
    const matchesSearch = !query || prompt.title.toLowerCase().includes(query) || prompt.content.toLowerCase().includes(query) || (prompt.command || '').toLowerCase().includes(query) || prompt.tags.some((tag) => tag.toLowerCase().includes(query));
    const matchesCategory = state.category === 'all' || prompt.category === state.category;
    return matchesSearch && matchesCategory;
  });
  const categories = ['all', ...new Set(state.prompts.map((item) => item.category))];

  cache.main.innerHTML = `
    <section class="panel">
      <div class="toolbar">
        <input id="promptSearch" type="search" placeholder="Search prompts" value="${esc(state.search)}" aria-label="Search prompts" />
        <button class="secondary-btn" id="clearSearch" type="button">Clear</button>
        <button class="primary-btn" id="toggleAddForm" type="button">${state.showAddPromptForm ? 'Cancel' : '+ Add your own prompt'}</button>
      </div>
      ${state.showAddPromptForm ? `
        <div class="detail-card add-prompt-form" style="margin-bottom:0.9rem;">
          <h4>Add your own prompt</h4>
          <input id="newPromptTitle" type="text" placeholder="Title (e.g. Weekly grocery planner)" required />
          <input id="newPromptCategory" list="categoryOptions" type="text" placeholder="Category (e.g. My Prompts)" />
          <datalist id="categoryOptions">${categories.filter((c) => c !== 'all').map((c) => `<option value="${esc(c)}">`).join('')}</datalist>
          <textarea id="newPromptContent" placeholder="Paste or write your prompt here..." required></textarea>
          <div class="card-actions">
            <button class="primary-btn" id="saveNewPrompt" type="button">Save prompt</button>
          </div>
        </div>
      ` : ''}
      <div class="chip-row">
        ${categories.map((category) => `<button class="chip-btn ${state.category === category ? 'active' : ''}" data-action="set-category" data-category="${esc(category)}" type="button">${category === 'all' ? 'All' : esc(category)}</button>`).join('')}
      </div>
      <div class="panel-header">
        <h3>${filteredPrompts.length} prompt${filteredPrompts.length === 1 ? '' : 's'}</h3>
      </div>
      <div class="prompt-grid">
        ${filteredPrompts.length ? filteredPrompts.map((prompt) => createPromptCard(prompt)).join('') : `<div class="empty-card"><div class="state-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></div><h3>No prompts found</h3><p>Try a different search term or category.</p></div>`}
      </div>
    </section>
  `;

  document.getElementById('clearSearch')?.addEventListener('click', () => {
    state.search = '';
    renderLibrary();
  });
  document.getElementById('toggleAddForm')?.addEventListener('click', () => {
    state.showAddPromptForm = !state.showAddPromptForm;
    renderLibrary();
  });
  document.getElementById('saveNewPrompt')?.addEventListener('click', () => {
    const title = document.getElementById('newPromptTitle').value.trim();
    const category = document.getElementById('newPromptCategory').value.trim();
    const content = document.getElementById('newPromptContent').value.trim();
    if (!title || !content) {
      showToast('Please add both a title and the prompt text.');
      return;
    }
    createCustomPrompt({ title, category, content });
    state.showAddPromptForm = false;
    showToast('Prompt saved to your library');
    renderLibrary();
  });
}

function renderLearn() {
  cache.main.innerHTML = `
    <section class="panel">
      <div class="panel-header">
        <h3>Learn AI</h3>
        <span class="meta-row">${state.lessons.length} lesson${state.lessons.length === 1 ? '' : 's'}</span>
      </div>
      <div class="lesson-grid">
        ${state.lessons.map((lesson) => createLessonCard(lesson)).join('')}
      </div>
    </section>
  `;
}

function renderLessonDetail() {
  const lesson = state.lessons.find((item) => item.id === state.selectedLessonId);
  if (!lesson) {
    navigateTo('learn');
    return;
  }
  cache.main.innerHTML = `
    <section class="detail-card">
      <div class="meta-row">
        <span>${esc(lesson.topic)}</span><span>•</span><span>${esc(lesson.level)}</span><span>•</span><span>${esc(lesson.duration)}</span>
      </div>
      <h2>${esc(lesson.title)}</h2>
      <p>${esc(lesson.description)}</p>
      <div class="lesson-body">
        ${(lesson.body || []).map((section) => `
          <div class="lesson-section">
            <h4>${esc(section.heading)}</h4>
            <p>${esc(section.text)}</p>
          </div>
        `).join('')}
      </div>
      <div class="card-actions">
        <button class="secondary-btn" data-action="back-to-learn" type="button">Back to lessons</button>
      </div>
    </section>
  `;
}

function renderTools() {
  const query = state.toolSearch.toLowerCase();
  const filteredTools = state.tools.filter((tool) => {
    const matchesSearch = !query || tool.name.toLowerCase().includes(query) || tool.description.toLowerCase().includes(query) || tool.category.toLowerCase().includes(query);
    const matchesCategory = state.toolCategory === 'all' || tool.category === state.toolCategory;
    return matchesSearch && matchesCategory;
  });
  const categories = ['all', ...new Set(state.tools.map((tool) => tool.category))];

  cache.main.innerHTML = `
    <section class="panel">
      <div class="toolbar">
        <input id="toolSearch" type="search" placeholder="Search AI tools" value="${esc(state.toolSearch)}" aria-label="Search AI tools" />
        <button class="secondary-btn" id="clearToolSearch" type="button">Clear</button>
      </div>
      <div class="chip-row">
        ${categories.map((category) => `<button class="chip-btn ${state.toolCategory === category ? 'active' : ''}" data-action="set-tool-category" data-category="${esc(category)}" type="button">${category === 'all' ? 'All' : esc(category)}</button>`).join('')}
      </div>
      <div class="panel-header">
        <h3>${filteredTools.length} tool${filteredTools.length === 1 ? '' : 's'}</h3>
      </div>
      <div class="tool-grid">
        ${filteredTools.length ? filteredTools.map((tool) => createToolCard(tool)).join('') : `<div class="empty-card"><div class="state-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></div><h3>No tools found</h3><p>Try a different search term or category.</p></div>`}
      </div>
    </section>
  `;

  document.getElementById('clearToolSearch')?.addEventListener('click', () => {
    state.toolSearch = '';
    state.toolCategory = 'all';
    renderTools();
  });
}

function renderGlossary() {
  const query = state.glossarySearch.toLowerCase();
  const filtered = state.glossary.filter((entry) => !query || entry.term.toLowerCase().includes(query) || entry.definition.toLowerCase().includes(query));

  cache.main.innerHTML = `
    <section class="panel">
      <div class="toolbar">
        <input id="glossarySearch" type="search" placeholder="Search AI terms" value="${esc(state.glossarySearch)}" aria-label="Search AI glossary" />
      </div>
      <div class="panel-header">
        <h3>AI Glossary</h3>
        <span class="meta-row">${filtered.length} term${filtered.length === 1 ? '' : 's'}</span>
      </div>
      <div class="glossary-list">
        ${filtered.length ? filtered.map((entry) => `
          <article class="detail-card glossary-item">
            <h4>${esc(entry.term)}</h4>
            <p>${esc(entry.definition)}</p>
            <p class="use-case"><strong>Example:</strong> ${esc(entry.example)}</p>
          </article>
        `).join('') : `<div class="empty-card"><div class="state-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="2"/><path d="m20 20-3.5-3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></div><h3>No terms found</h3><p>Try a different search word.</p></div>`}
      </div>
    </section>
  `;
}

function renderFavorites() {
  const favorites = state.prompts.filter((prompt) => state.favorites.has(prompt.id));
  cache.main.innerHTML = `
    <section class="panel">
      <div class="panel-header">
        <h3>Favorites</h3>
        <span class="meta-row">${favorites.length} saved</span>
      </div>
      <div class="prompt-grid">
        ${favorites.length ? favorites.map((prompt) => createPromptCard(prompt)).join('') : `<div class="empty-card"><div class="state-icon">${ICONS.star}</div><h3>No favorites yet</h3><p>Tap the star on any prompt to save it here for quick access.</p><div class="card-actions"><button class="primary-btn" data-view="library" type="button">Browse the library</button></div></div>`}
      </div>
    </section>
  `;
}

function renderSettings() {
  cache.main.innerHTML = `
    <section class="panel">
      <div class="panel-header"><h3>Settings</h3></div>
      <div class="detail-card" style="margin-bottom:0.8rem;">
        <h4>Appearance</h4>
        <p>Switch between dark and light themes to fit your workspace.</p>
        <div class="card-actions">
          <button class="primary-btn" id="themeSettingToggle" type="button">${state.theme === 'light' ? 'Use dark theme' : 'Use light theme'}</button>
        </div>
      </div>
      <div class="detail-card" style="margin-bottom:0.8rem;">
        <h4>Accent color</h4>
        <p>Pick an accent theme — works with both dark and light mode.</p>
        <div class="swatch-row" style="margin-top:0.6rem;">
          <button class="swatch-btn ${state.accent === 'nebula' ? 'active' : ''}" data-action="set-accent" data-accent="nebula" type="button"><span class="swatch-dot nebula"></span>Nebula</button>
          <button class="swatch-btn ${state.accent === 'ember' ? 'active' : ''}" data-action="set-accent" data-accent="ember" type="button"><span class="swatch-dot ember"></span>Ember</button>
          <button class="swatch-btn ${state.accent === 'lagoon' ? 'active' : ''}" data-action="set-accent" data-accent="lagoon" type="button"><span class="swatch-dot lagoon"></span>Lagoon</button>
        </div>
      </div>
      <div class="detail-card" style="margin-bottom:0.8rem;">
        <h4>Favorites</h4>
        <p>Export or import your saved prompts for backup or transfer.</p>
        <div class="card-actions">
          <button class="secondary-btn" id="exportFavorites" type="button">Export favorites</button>
          <label class="secondary-btn" style="display:inline-flex; align-items:center; justify-content:center;" for="importFavorites">Import favorites</label>
          <input id="importFavorites" class="hidden" type="file" accept="application/json" />
        </div>
      </div>
      <div class="detail-card">
        <h4>Accessibility</h4>
        <p>Keyboard focus and screen-reader support are built in with visible focus states, semantic headings, and live status messages.</p>
      </div>
    </section>
  `;

  document.getElementById('themeSettingToggle')?.addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('promptHubTheme', state.theme);
    applyTheme();
    renderSettings();
  });
  document.getElementById('exportFavorites')?.addEventListener('click', exportFavorites);
}

function renderAbout() {
  cache.main.innerHTML = `
    <section class="hero-card">
      <h2>About PromptHub AI</h2>
      <p>PromptHub AI is a focused workspace for people who use AI daily — a curated prompt library, real lessons on prompt design, an AI glossary, and a working directory of AI tools. Every piece of content here is written to be genuinely useful, not filler.</p>
    </section>

    <section class="panel">
      <div class="panel-header"><h3>What's inside</h3></div>
      <div class="detail-card">
        <p>${state.prompts.length} hand-written prompts across ${new Set(state.prompts.map(p => p.category)).size} categories, ${state.lessons.length} full lessons on prompt design and workflow, ${state.tools.length} real AI tools with direct links, and a growing AI glossary.</p>
      </div>
    </section>

    <section class="panel">
      <div class="panel-header"><h3>About the Creator</h3></div>
      <div class="detail-card creator-card">
        <div class="creator-avatar">WA</div>
        <div>
          <h4>Khaja Waseem Ahmed Adil</h4>
          <p class="creator-role">Founder &amp; Creator of PromptHub AI</p>
          <p class="creator-location">📍 Hyderabad, India</p>
        </div>
      </div>
      <div class="detail-card" style="margin-top:0.7rem;">
        <h4>Mission</h4>
        <p>Make practical AI fluency accessible to everyone — not through information overload, but through a small set of things that are genuinely worth your time: prompts that work, lessons that teach real skills, and tools that are actually worth using.</p>
      </div>
      <div class="detail-card" style="margin-top:0.7rem;">
        <h4>Vision</h4>
        <p>To be the AI companion people trust for quality over quantity — a curated space that grows carefully over time rather than trying to capture the entire, ever-changing AI landscape at once.</p>
      </div>
    </section>

    <section class="panel">
      <div class="panel-header"><h3>Reviews</h3></div>
      <div class="empty-card">
        <div class="state-icon">${ICONS.star}</div>
        <h3>No reviews yet</h3>
        <p>PromptHub AI is brand new — this section will fill up with real feedback as people start using it. No fake reviews here, just honest ones as they come in.</p>
        <div class="card-actions">
          <button class="primary-btn" data-action="open-link" data-href="mailto:feedback@prompthub.ai" type="button">Be the first to share feedback</button>
        </div>
      </div>
    </section>

    <section class="panel">
      <div class="panel-header"><h3>Get in touch</h3></div>
      <div class="grid-2">
        <button class="secondary-btn" data-action="open-link" data-href="mailto:hello@prompthub.ai" type="button">✉️ Contact</button>
        <button class="secondary-btn" data-action="open-link" data-href="mailto:feedback@prompthub.ai" type="button">💬 Send feedback</button>
        <button class="secondary-btn" data-action="open-link" data-href="https://github.com/" type="button">🔗 GitHub</button>
        <button class="secondary-btn" data-action="set-legal" data-legal="privacy" type="button">Privacy Policy</button>
        <button class="secondary-btn" data-action="set-legal" data-legal="terms" type="button">Terms of Use</button>
        <button class="secondary-btn" data-action="set-legal" data-legal="changelog" type="button">Version history</button>
      </div>
    </section>

    <section id="legalPanel" class="panel hidden"></section>

    <section class="panel">
      <div class="panel-header"><h3>Credits</h3></div>
      <div class="detail-card">
        <p>Built with HTML, CSS, and vanilla JavaScript. Packaged as a Progressive Web App with offline support via a service worker. No tracking, no ads, no accounts required — your favorites and progress are stored only on your device.</p>
      </div>
    </section>
  `;
}

const LEGAL_CONTENT = {
  privacy: {
    title: 'Privacy Policy',
    body: `PromptHub AI does not collect, transmit, or sell personal data. Your favorites, search history, and preferences are stored locally on your device using browser storage (localStorage) and never leave your device. The app makes no network requests to external servers for its core content — all prompts, lessons, and tool listings are bundled with the app itself. If a future version adds optional cloud sync, this policy will be updated before that feature is enabled, and it will be opt-in.`,
  },
  terms: {
    title: 'Terms of Use',
    body: `PromptHub AI is provided as-is, for personal and professional productivity use. Prompt content is provided as a starting point for your own work with AI models — outputs from any AI tool linked or referenced in this app are the responsibility of the user. Tool descriptions and pricing are believed accurate at time of writing but may change; always check the official website (linked on each tool) for current pricing and terms. This app is not affiliated with OpenAI, Anthropic, Google, or any AI tool listed unless explicitly stated.`,
  },
  changelog: {
    title: 'Version history',
    body: `v1.0 — Initial public release: prompt library, AI tools directory, Learn section with full lesson content, favorites with export/import, offline support, dark/light themes.\nv1.1 — Sidebar + mobile drawer navigation, Material 3 visual refresh, command-style prompt identifiers (e.g. /HandwrittenNotes), About/Creator page, AI Glossary, Daily Tip and Quote of the Day.`,
  },
};

function renderDetail() {
  const prompt = state.prompts.find((item) => item.id === state.selectedPromptId);
  if (!prompt) {
    navigateTo('library');
    return;
  }
  const related = state.prompts.filter((item) => item.category === prompt.category && item.id !== prompt.id).slice(0, 3);
  cache.main.innerHTML = `
    <section class="detail-card">
      <div class="meta-row">
        <span>${esc(prompt.category)}</span><span>•</span><span>${esc(prompt.subcategory)}</span>
        ${prompt.difficulty ? `<span>•</span><span>${esc(prompt.difficulty)}</span>` : ''}
      </div>
      <h2>${esc(prompt.title)}</h2>
      ${prompt.command ? `<code class="command-chip">${esc(prompt.command)}</code>` : ''}
      ${prompt.use_case ? `<p class="use-case"><strong>Use for:</strong> ${esc(prompt.use_case)}</p>` : ''}
      <p class="prompt-content">${esc(prompt.content)}</p>
      <div class="tag" style="margin-top:0.8rem">${prompt.tags.map(esc).join(' • ')}</div>
      <div class="card-actions">
        <button class="primary-btn" data-action="toggle-favorite" data-id="${prompt.id}" type="button">${state.favorites.has(prompt.id) ? ICONS.starFilled + ' Saved' : ICONS.star + ' Save'}</button>
        <button class="secondary-btn" data-action="copy" data-id="${prompt.id}" type="button">Copy</button>
        <button class="secondary-btn" data-action="share" data-id="${prompt.id}" type="button">Share</button>
        <button class="secondary-btn" data-action="back" type="button">Back to library</button>
      </div>
      <div class="card-actions" style="margin-top:0.4rem;">
        <button class="secondary-btn" data-action="try-chatgpt" data-id="${prompt.id}" type="button">Try free in ChatGPT ↗</button>
        <button class="secondary-btn" data-action="try-claude" data-id="${prompt.id}" type="button">Try free in Claude ↗</button>
        ${prompt.isCustom ? `<button class="secondary-btn" data-action="delete-custom" data-id="${prompt.id}" type="button">Delete this prompt</button>` : ''}
      </div>
    </section>

    ${related.length ? `
    <section class="panel">
      <div class="panel-header"><h3>Related prompts</h3></div>
      <div class="prompt-grid">
        ${related.map((item) => createPromptCard(item, true)).join('')}
      </div>
    </section>` : ''}
  `;
}

// ---------- Card templates (all dynamic data escaped) ----------

function createPromptCard(prompt, compact = false) {
  const isFavorite = state.favorites.has(prompt.id);
  const previewText = compact ? prompt.content.slice(0, 140) + (prompt.content.length > 140 ? '...' : '') : prompt.content;
  return `
    <article class="prompt-card">
      <div class="meta-row">
        <span>${esc(prompt.category)}</span><span>•</span><span>${esc(prompt.subcategory)}</span>
        ${prompt.difficulty ? `<span class="tag">${esc(prompt.difficulty)}</span>` : ''}
        ${prompt.isCustom ? `<span class="tag custom-badge">Yours</span>` : ''}
      </div>
      <h4>${esc(prompt.title)}</h4>
      ${prompt.command ? `<code class="command-chip">${esc(prompt.command)}</code>` : ''}
      <p>${esc(previewText)}</p>
      <div class="card-actions">
        <button class="icon-btn ${isFavorite ? 'active' : ''}" data-action="toggle-favorite" data-id="${prompt.id}" type="button" aria-pressed="${isFavorite}">${isFavorite ? ICONS.starFilled : ICONS.star}</button>
        <button class="icon-btn" data-action="details" data-id="${prompt.id}" type="button">Details</button>
        <button class="icon-btn" data-action="copy" data-id="${prompt.id}" type="button">Copy</button>
        <button class="icon-btn" data-action="share" data-id="${prompt.id}" type="button">Share</button>
        ${prompt.isCustom ? `<button class="icon-btn" data-action="delete-custom" data-id="${prompt.id}" type="button">Delete</button>` : ''}
      </div>
    </article>
  `;
}

function createLessonCard(lesson) {
  return `
    <article class="lesson-card">
      <div class="meta-row"><span>${esc(lesson.level)}</span><span>•</span><span>${esc(lesson.duration)}</span></div>
      <h4>${esc(lesson.title)}</h4>
      <p>${esc(lesson.description)}</p>
      <div class="card-actions">
        <span class="tag">${esc(lesson.topic)}</span>
        <button class="icon-btn" data-action="open-lesson" data-id="${lesson.id}" type="button">Start lesson →</button>
      </div>
    </article>
  `;
}

function createToolCard(tool) {
  return `
    <article class="tool-card">
      <div class="meta-row"><span>${esc(tool.category)}</span><span>•</span><span>${esc(tool.pricing)}</span></div>
      <h4>${esc(tool.name)}</h4>
      <p>${esc(tool.description)}</p>
      <div class="card-actions">
        <span class="tag">${esc(tool.bestFor)}</span>
        ${tool.url ? `<a class="icon-btn" href="${esc(tool.url)}" target="_blank" rel="noopener noreferrer">Visit tool ↗</a>` : ''}
      </div>
    </article>
  `;
}

// ---------- Actions ----------

function handleMainAction(event) {
  const target = event.target.closest('button, a[data-action]');
  if (!target) return;

  if (target.dataset.view) {
    navigateTo(target.dataset.view, null);
    return;
  }

  const action = target.dataset.action;
  if (action === 'retry') return loadData();
  if (action === 'back' || action === 'back-to-learn') return navigateTo(action === 'back' ? 'library' : 'learn');
  if (action === 'set-category') {
    state.category = target.dataset.category;
    renderLibrary();
    return;
  }
  if (action === 'set-tool-category') {
    state.toolCategory = target.dataset.category;
    renderTools();
    return;
  }
  if (action === 'set-accent') {
    setAccent(target.dataset.accent);
    return;
  }
  if (action === 'open-lesson') {
    navigateTo('lesson', Number(target.dataset.id));
    return;
  }
  if (action === 'open-link') {
    window.open(target.dataset.href, '_blank', 'noopener,noreferrer');
    return;
  }
  if (action === 'set-legal') {
    const panel = document.getElementById('legalPanel');
    const entry = LEGAL_CONTENT[target.dataset.legal];
    if (!panel || !entry) return;
    panel.classList.remove('hidden');
    panel.innerHTML = `
      <div class="panel-header"><h3>${esc(entry.title)}</h3></div>
      <div class="detail-card"><p style="white-space:pre-line">${esc(entry.body)}</p></div>
    `;
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    return;
  }

  if (!target.dataset.id) return;
  const id = Number(target.dataset.id);
  const prompt = state.prompts.find((item) => item.id === id);
  if (!prompt) return;

  if (action === 'details') return navigateTo('detail', prompt.id);

  if (action === 'toggle-favorite') {
    if (state.favorites.has(prompt.id)) {
      state.favorites.delete(prompt.id);
      showToast('Removed from favorites');
    } else {
      state.favorites.add(prompt.id);
      showToast('Added to favorites');
    }
    persistFavorites();
    render();
    return;
  }

  if (action === 'copy') copyToClipboard(prompt.content);
  if (action === 'share') sharePrompt(prompt);
  if (action === 'delete-custom') {
    deleteCustomPrompt(prompt.id);
    showToast('Prompt deleted');
    if (state.view === 'detail') navigateTo('library');
    else render();
  }
  if (action === 'try-chatgpt') openInFreeAI(prompt.content, 'https://chat.openai.com', 'ChatGPT');
  if (action === 'try-claude') openInFreeAI(prompt.content, 'https://claude.ai/new', 'Claude');
}

/** Copies the prompt to clipboard and opens the free chat site in a new tab — no API key, no backend, no cost. */
async function openInFreeAI(content, url, label) {
  await copyToClipboard(content);
  window.open(url, '_blank', 'noopener,noreferrer');
  showToast(`Copied — paste it into ${label}`);
}

function persistFavorites() {
  localStorage.setItem('promptHubFavorites', JSON.stringify([...state.favorites]));
}

function getCustomPrompts() {
  return state.prompts.filter((prompt) => prompt.isCustom);
}

function saveCustomPrompts() {
  localStorage.setItem('promptHubCustomPrompts', JSON.stringify(getCustomPrompts()));
}

function nextCustomId() {
  const current = Number(localStorage.getItem('promptHubCustomNextId') || '9000');
  localStorage.setItem('promptHubCustomNextId', String(current + 1));
  return current;
}

function createCustomPrompt({ title, category, content }) {
  const prompt = {
    id: nextCustomId(),
    title: title.trim(),
    command: '',
    category: category.trim() || 'My Prompts',
    subcategory: 'Custom',
    difficulty: '',
    use_case: '',
    content: content.trim(),
    tags: ['custom'],
    isCustom: true,
  };
  state.prompts.push(prompt);
  saveCustomPrompts();
  return prompt;
}

function deleteCustomPrompt(id) {
  state.prompts = state.prompts.filter((prompt) => prompt.id !== id);
  state.favorites.delete(id);
  persistFavorites();
  saveCustomPrompts();
}

async function copyToClipboard(value) {
  try {
    await navigator.clipboard.writeText(value);
    showToast('Prompt copied to clipboard');
  } catch (error) {
    showToast('Clipboard access failed');
  }
}

async function sharePrompt(prompt) {
  const shareText = `${prompt.title}\n\n${prompt.content}`;
  if (navigator.share) {
    try {
      await navigator.share({ title: prompt.title, text: shareText });
      showToast('Prompt shared');
    } catch {
      showToast('Share cancelled');
    }
    return;
  }
  copyToClipboard(shareText);
}

function exportFavorites() {
  const favorites = state.prompts.filter((prompt) => state.favorites.has(prompt.id));
  const blob = new Blob([JSON.stringify(favorites, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'promptHub-favorites.json';
  link.click();
  URL.revokeObjectURL(url);
  showToast('Favorites exported');
}

function importFavorites(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      const importedIds = new Set(imported.map((item) => item.id));
      state.favorites = new Set([...state.favorites, ...importedIds]);
      persistFavorites();
      render();
      showToast('Favorites imported');
    } catch {
      showToast('The selected file could not be imported.');
    }
  };
  reader.readAsText(file);
}

function showToast(message) {
  cache.toast.textContent = message;
  cache.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => cache.toast.classList.remove('show'), 2200);
}

function updateSidebarActive() {
  document.querySelectorAll('.nav-item[data-view]').forEach((button) => {
    button.classList.toggle('active', button.dataset.view === state.view);
  });
}

function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch((error) => console.error('SW registration failed', error));
  }
}

document.addEventListener('DOMContentLoaded', init);
