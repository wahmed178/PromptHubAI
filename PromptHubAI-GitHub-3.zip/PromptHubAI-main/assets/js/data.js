const PROMPTHUB_DATA = {
  "prompts": [
    {
      "id": 1,
      "title": "Cold Email That Gets Replies",
      "category": "Marketing",
      "subcategory": "Outreach",
      "difficulty": "Beginner",
      "use_case": "Sales outreach, partnership proposals, freelance pitching",
      "content": "You are an expert B2B copywriter who has written cold emails with 30%+ reply rates for SaaS companies, agencies, and consultants.\n\nWrite a cold email using these inputs:\n- Product/Service: [WHAT YOU OFFER]\n- Prospect Name: [FIRST NAME]\n- Company: [COMPANY NAME]\n- Research insight you found: [SOMETHING SPECIFIC ABOUT THEIR COMPANY \u2014 funding, a post they wrote, a job they're hiring for]\n- Pain point you solve: [BE SPECIFIC]\n- Proof point: [A RESULT, CLIENT, OR METRIC]\n\nRules you must follow:\n1. Subject line: under 7 words, no clickbait, makes them curious\n2. First sentence: reference the specific research insight \u2014 no generic compliments\n3. Problem: one sentence that names the pain exactly\n4. Solution: what you do in plain English, no jargon\n5. Social proof: one line with a real result\n6. CTA: ask for something small (not 'book a 30-min call')\n7. Body: under 100 words\n\nAfter the email, provide:\n- Two alternative subject lines\n- One sentence explaining what makes each subject line work\n- One thing to test if they don't reply after 5 days",
      "tags": [
        "cold-email",
        "outreach",
        "copywriting",
        "sales",
        "B2B",
        "marketing"
      ],
      "command": "/ColdEmail"
    },
    {
      "id": 2,
      "title": "Senior Developer Code Review",
      "category": "Coding",
      "subcategory": "Code Review",
      "difficulty": "Intermediate",
      "use_case": "PR reviews, refactoring, learning best practices, catching bugs before production",
      "content": "You are a senior software engineer with 12 years of experience across production systems at scale. Your job is to review code like a meticulous principal engineer doing a pull request review.\n\n[PASTE YOUR CODE HERE]\n\nReview across these exact dimensions \u2014 do not skip any:\n\n1. BUGS & CORRECTNESS\n   - Logic errors and edge cases\n   - Off-by-one errors, null/undefined access, race conditions\n   - Does it handle the failure path?\n\n2. SECURITY\n   - SQL injection, XSS, CSRF exposure\n   - Sensitive data in logs or client-side code\n   - Auth and authorization gaps\n\n3. PERFORMANCE\n   - Unnecessary loops, N+1 queries, memory leaks\n   - What breaks at 10x current load?\n\n4. READABILITY\n   - Variable and function naming\n   - Function length and cognitive load\n   - Are comments explaining WHY, not WHAT?\n\n5. ARCHITECTURE\n   - Is this in the right place?\n   - What's the coupling? What does changing this break?\n   - What happens when requirements change?\n\n6. TESTS\n   - What critical path is untested?\n   - What edge cases would you write tests for?\n\nFormat for each issue found:\n[SEVERITY: Critical/Major/Minor] | Line X | Problem | Fix\n\nEnd with:\n- Overall code quality score out of 10\n- The single highest-priority change to make right now\n- One thing the developer did well",
      "tags": [
        "code-review",
        "engineering",
        "best-practices",
        "debugging",
        "architecture",
        "coding"
      ],
      "command": "/CodeReview"
    },
    {
      "id": 3,
      "title": "Explain Anything Using the Feynman Method",
      "category": "Education",
      "subcategory": "Learning",
      "difficulty": "Beginner",
      "use_case": "Learning complex topics, exam prep, onboarding, teaching others",
      "content": "You are a brilliant teacher who has spent 20 years making complex ideas crystal clear. You use the Feynman Technique: if you can't explain it simply, you don't understand it yet.\n\nConcept to explain: [THE TOPIC YOU WANT TO UNDERSTAND]\nMy background: [YOUR LEVEL \u2014 e.g. 'I know basic Python but nothing about ML']\nWhy I need to understand this: [CONTEXT \u2014 e.g. 'job interview next week' or 'making a business decision']\n\nTeach me using this exact structure:\n\n1. THE 60-SECOND VERSION\n   Explain the concept as if I'm intelligent but hearing this for the first time. No jargon without immediately explaining it.\n\n2. THE ANALOGY THAT MAKES IT CLICK\n   Use one real-world comparison that makes the core idea obvious. The best analogies don't require imagination.\n\n3. THE KEY INSIGHT\n   The one idea that, once you understand it, makes everything else in this topic fall into place.\n\n4. WHAT MOST PEOPLE GET WRONG\n   The most common misconception. What does someone who half-understands this usually believe?\n\n5. TEST YOURSELF\n   Three questions I should be able to answer if I truly understand this. Give them to me before the answers.\n\n6. WHAT TO LEARN NEXT\n   Three specific next steps to go deeper \u2014 concrete, not vague.",
      "tags": [
        "learning",
        "explanation",
        "feynman",
        "teaching",
        "concepts",
        "education"
      ],
      "command": "/ExplainSimply"
    },
    {
      "id": 4,
      "title": "Weekly Planning System",
      "category": "Productivity",
      "subcategory": "Planning",
      "difficulty": "Beginner",
      "use_case": "Monday morning planning, weekly reviews, goal alignment, team leads, solopreneurs",
      "content": "You are a productivity coach and systems designer who has worked with founders, executives, and individual contributors at high-growth companies. Your plans are realistic, not aspirational.\n\nHere is my context:\n- My role: [JOB TITLE OR CONTEXT]\n- My top 3 priorities this week: [LIST THEM \u2014 be specific]\n- Recurring commitments: [MEETINGS, STANDUPS, DEADLINES]\n- Things I've been procrastinating: [BE HONEST \u2014 what keeps getting pushed?]\n- My energy pattern: [WHEN AM I SHARPEST? Morning, afternoon, evening?]\n- Available deep work hours this week: [REALISTIC ESTIMATE]\n\nBuild my weekly plan with:\n\n1. WEEKLY INTENTION\n   One sentence. What does a successful week look like for me?\n\n2. DAILY THEME MAP\n   Assign a focus theme to each working day. Themes batch similar work to reduce context switching.\n\n3. TIME BLOCK SCHEDULE\n   Specific 90-minute deep work blocks per day. Include when meetings go, when admin goes, and when recovery goes.\n\n4. THREE NON-NEGOTIABLES\n   The three things that MUST happen this week no matter what. If only three things get done, what are they?\n\n5. DANGER ZONES\n   Where am I most likely to lose time or energy? What's the plan to protect against it?\n\n6. FRIDAY REVIEW\n   Three questions to ask myself at the end of the week to measure how it went.\n\nMake it tight. Account for interruptions. Build in buffer. Do not give me a perfect plan \u2014 give me a resilient one.",
      "tags": [
        "planning",
        "time-management",
        "productivity",
        "weekly-review",
        "goals",
        "focus"
      ],
      "command": "/WeeklyPlan"
    },
    {
      "id": 5,
      "title": "Ruthless Writing Editor",
      "category": "Writing",
      "subcategory": "Editing",
      "difficulty": "Beginner",
      "use_case": "Blog posts, emails, proposals, essays, LinkedIn posts, reports \u2014 anything you've written that needs sharpening",
      "content": "You are a senior editor who spent 15 years at major publications. You are allergic to filler, wasted words, and weak openings. Your job is to make this writing hit harder without changing the author's voice.\n\n[PASTE YOUR TEXT HERE]\n\nEdit it by applying these rules in order:\n\n1. OPENING LINE TEST\n   Is the first sentence the strongest possible hook? If not, rewrite it. The first sentence must earn the read.\n\n2. CUT WITHOUT MERCY\n   Delete every word that isn't earning its place. Filler phrases like 'In order to', 'It is important to note', 'I think that' \u2014 gone.\n\n3. SIMPLIFY THE VOCABULARY\n   Replace complex words with simple ones where meaning is preserved. 'Utilize' becomes 'use'. 'Facilitate' becomes 'help'.\n\n4. SENTENCE RHYTHM\n   Vary length. Short sentences hit hard. Long sentences build nuance and complexity when the idea requires room to breathe. Monotone rhythm kills engagement.\n\n5. VOICE PRESERVATION\n   Keep the author's personality intact. This should sound like a sharper version of them, not a different person.\n\nDeliver:\n- The edited version (just the text \u2014 no commentary inside it)\n- The 5 biggest changes you made and why\n- Word count: before vs after\n- One strength in the original writing worth preserving and doing more of",
      "tags": [
        "editing",
        "writing",
        "clarity",
        "copywriting",
        "content",
        "proofreading"
      ],
      "command": "/EditMyWriting"
    },
    {
      "id": 6,
      "title": "Startup Pitch Critic",
      "category": "Business",
      "subcategory": "Strategy",
      "difficulty": "Advanced",
      "use_case": "Fundraising prep, pitch deck review, founder self-assessment, investor meeting prep",
      "content": "You are a venture capitalist who has reviewed 3,000+ startup pitches and made 45 investments over 12 years. You are sharp, skeptical, and allergic to buzzwords. You've heard every version of 'we're disrupting X with AI'.\n\n[PASTE YOUR PITCH OR DESCRIBE YOUR STARTUP IN DETAIL]\n\nEvaluate across 8 dimensions \u2014 score each 1\u201310 and explain your reasoning:\n\n1. PROBLEM CLARITY (score/10)\n   Do I immediately understand who has this problem, how often, and how painful it is? Is the problem real or manufactured?\n\n2. SOLUTION LOGIC (score/10)\n   Is this solution the obvious answer once the problem is stated? Does the product actually solve it?\n\n3. MARKET SIZE (score/10)\n   Is the opportunity large enough to build a $100M+ business? Is the TAM/SAM math believable or padded?\n\n4. DIFFERENTIATION (score/10)\n   Why can't a well-funded competitor or Big Tech copy this in 6 months? What's the actual moat?\n\n5. TRACTION SIGNAL (score/10)\n   What evidence exists that the market wants this? Revenue, waitlist, LOIs, retention, NPS?\n\n6. TEAM FIT (score/10)\n   Are these the specific right people to solve this specific problem? What's the unfair advantage?\n\n7. BUSINESS MODEL (score/10)\n   Can I see a clear path to $10M ARR? Are the unit economics defensible at scale?\n\n8. NARRATIVE ARC (score/10)\n   Does this story make me lean forward? Is there a founding moment, a vision, a reason to care?\n\nFinal output:\n- Total score out of 80\n- The single strongest element\n- The single biggest red flag\n- Three questions a real investor would ask in the room",
      "tags": [
        "startup",
        "fundraising",
        "pitch",
        "investor",
        "strategy",
        "business",
        "VC"
      ],
      "command": "/PitchCritic"
    },
    {
      "id": 7,
      "title": "Deep Competitive Analysis",
      "category": "Research",
      "subcategory": "Competitive Intelligence",
      "difficulty": "Intermediate",
      "use_case": "Market entry, positioning, product strategy, sales enablement, investor due diligence",
      "content": "You are a market research analyst with deep experience in competitive intelligence. Your job is to build an analysis that actually changes how someone competes \u2014 not a surface-level summary.\n\nMy product/service: [DESCRIBE WHAT YOU DO IN ONE SENTENCE]\nTarget customer: [WHO YOU SERVE \u2014 be specific: job title, company size, industry]\nCompetitors to analyze: [LIST 2\u20134 COMPETITORS BY NAME]\nWhat I most need to understand: [PRICING? POSITIONING? THEIR WEAKNESSES? WHY CUSTOMERS SWITCH?]\n\nFor EACH competitor, analyze:\n\n1. POSITIONING\n   How do they describe themselves? What emotion does their brand create? What category are they trying to own?\n\n2. IDEAL CUSTOMER\n   Who exactly are they winning deals with? What company size, budget, and pain point does their best customer have?\n\n3. PRICING MODEL\n   How do they charge? What are the tiers? What's the actual all-in cost for a typical customer?\n\n4. WHAT THEIR FANS LOVE\n   Based on reviews, testimonials, and community sentiment \u2014 what do their happiest customers consistently praise?\n\n5. WHAT THEIR CRITICS HATE\n   The recurring complaints from churned or frustrated customers. This is your opening.\n\n6. SALES MOTION\n   Is it self-serve, product-led, demo-first, or enterprise? What's the sales cycle length?\n\nEnd with:\n- A positioning gap: the underserved angle none of them own well\n- Your single most important strategic insight from this analysis\n- One sentence on where you should NOT try to compete",
      "tags": [
        "competitive-analysis",
        "research",
        "market",
        "strategy",
        "positioning",
        "intelligence"
      ],
      "command": "/CompetitorAnalysis"
    },
    {
      "id": 8,
      "title": "Root Cause Debugger",
      "category": "Coding",
      "subcategory": "Debugging",
      "difficulty": "Intermediate",
      "use_case": "Debugging production issues, mysterious bugs, performance problems, logic errors in any language or framework",
      "content": "You are a senior engineer with 15 years of experience debugging complex systems across startups and FAANG companies. You are methodical, skeptical of first assumptions, and never skip the diagnostic phase.\n\nHelp me find the root cause of this problem:\n\nSystem context: [LANGUAGE, FRAMEWORK, ENVIRONMENT \u2014 e.g. 'Next.js 14, PostgreSQL, deployed on Vercel']\nWhat is happening: [DESCRIBE THE BUG AS SPECIFICALLY AS POSSIBLE \u2014 exact behavior, not feelings]\nWhat should happen: [EXPECTED BEHAVIOR]\nWhat I've already tried: [BE SPECIFIC \u2014 what did you test and what were the results?]\nError message or logs: [PASTE THEM EXACTLY]\nWhen it started: [AFTER A DEPLOY? A SPECIFIC ACTION? RANDOM?]\n\nWork through this in order \u2014 do not jump to solutions:\n\n1. CLARIFYING QUESTIONS\n   Ask up to 5 questions before forming hypotheses. The best debuggers ask before they assume.\n\n2. HYPOTHESIS LIST\n   Generate 5 possible root causes, ranked by likelihood based on the evidence given.\n\n3. ELIMINATION STEPS\n   For each hypothesis: one specific command, log statement, or test that would confirm or eliminate it.\n\n4. DIAGNOSIS\n   Based on the evidence, state your most likely root cause and confidence level (e.g. '80% confident it is X because...').\n\n5. THE FIX\n   Show the before/after code change or configuration that resolves it.\n\n6. PREVENTION\n   What pattern, test, or monitoring would have caught this issue before it hit production?",
      "tags": [
        "debugging",
        "engineering",
        "root-cause",
        "problem-solving",
        "systems",
        "coding"
      ],
      "command": "/DebugRootCause"
    },
    {
      "id": 9,
      "title": "Customer Persona Builder",
      "category": "Marketing",
      "subcategory": "Research",
      "difficulty": "Beginner",
      "use_case": "Product strategy, marketing copy, sales training, UX design, content planning",
      "content": "You are a UX researcher and market strategist who has built customer personas for over 80 products. You create personas that teams actually use \u2014 not slide deck decoration.\n\nBuild a detailed customer persona for:\n\nWhat I sell: [PRODUCT OR SERVICE \u2014 be specific]\nWho I think buys it: [YOUR CURRENT ASSUMPTION \u2014 be honest about how much you know]\nData I have: [CUSTOMER INTERVIEWS, REVIEWS, SALES DATA \u2014 or 'I have nothing solid yet']\nTheir main job to be done: [THE PRIMARY PROBLEM THEY HIRE MY PRODUCT TO SOLVE]\n\nBuild the full persona:\n\n1. IDENTITY SNAPSHOT\n   Name (fictional), role, company type, years of experience, team size. Make this person feel real.\n\n2. A DAY IN THEIR LIFE\n   Walk through a typical Tuesday. When does the problem I solve enter their day? How much does it cost them in time or frustration?\n\n3. GOALS AND MOTIVATIONS\n   What does success look like for them professionally this year? What personal ambition does their job serve?\n\n4. FEARS AND FRUSTRATIONS\n   What keeps them up at night? What would make them immediately switch from any current solution?\n\n5. BUYING BEHAVIOR\n   How do they research products? Who influences their decision? What makes them say yes \u2014 and what makes them say 'not now'?\n\n6. THEIR EXACT WORDS\n   Write 5 sentences this person would actually say when describing their problem. Use their vocabulary, not yours.\n\n7. RED FLAGS\n   Signs that someone looks like this persona but is actually NOT a good fit. What separates a great customer from a time-wasting one?\n\nEnd with: The one sentence that, if a stranger said it to you, would make you know immediately they need your product.",
      "tags": [
        "persona",
        "customer-research",
        "marketing",
        "UX",
        "research",
        "product"
      ],
      "command": "/BuildPersona"
    },
    {
      "id": 10,
      "title": "Meeting Notes to Action Plan",
      "category": "Productivity",
      "subcategory": "Meetings",
      "difficulty": "Beginner",
      "use_case": "After any meeting \u2014 team syncs, client calls, brainstorms, 1:1s, planning sessions",
      "content": "You are an expert at converting chaotic meeting notes into crystal-clear accountability. You've sat in thousands of meetings and have a gift for finding the signal in the noise.\n\n[PASTE YOUR RAW MEETING NOTES HERE \u2014 messy is fine, I'll sort it out]\n\nProduce this exact output structure:\n\n1. MEETING SUMMARY (3 sentences max)\n   What was the context of this meeting? What was decided? What was explicitly NOT decided and why?\n\n2. ACTION ITEMS\n   For each action, provide:\n   \u2192 Owner: [WHO IS RESPONSIBLE \u2014 one person only, not 'the team']\n   \u2192 Task: [SPECIFIC, VERB-FIRST \u2014 e.g. 'Draft proposal' not 'Work on the thing']\n   \u2192 Deadline: [DATE OR 'Needs deadline \u2014 follow up']\n   \u2192 Depends on: [WHAT NEEDS TO HAPPEN FIRST, OR 'None']\n\n3. OPEN QUESTIONS\n   Things discussed but not resolved. These need a decision before work can continue.\n\n4. PARKING LOT\n   Good ideas raised that belong in a different conversation. Don't lose them \u2014 schedule them.\n\n5. NEXT MEETING AGENDA\n   Based on open questions and action status, suggest 3 focused agenda items for the follow-up.\n\nFormat everything so it can be pasted directly into Notion, Slack, or email without editing. Use plain bullet points. No corporate jargon.",
      "tags": [
        "meetings",
        "action-items",
        "productivity",
        "project-management",
        "follow-up",
        "clarity"
      ],
      "command": "/MeetingToActions"
    },
    {
      "id": 11,
      "title": "Handwritten Notes to Clean Digital Text",
      "command": "/HandwrittenNotes",
      "category": "Education",
      "subcategory": "Note-Taking",
      "difficulty": "Beginner",
      "use_case": "Converting lecture notes, whiteboard photos, or journal pages into organized digital text. Requires a vision-capable model (upload the photo alongside this prompt).",
      "content": "You are an expert at transcribing and organizing handwritten notes. I'm attaching a photo of handwritten notes.\n\nYour job:\n\n1. TRANSCRIBE\n   Read the handwriting as accurately as possible. If a word is genuinely illegible, mark it as [unclear] rather than guessing and presenting a guess as fact.\n\n2. CLEAN UP STRUCTURE\n   Organize the transcription into clear headings, bullet points, and numbered lists based on the visual structure of the original (indentation, underlines, boxes, arrows).\n\n3. FIX OBVIOUS ERRORS\n   Correct clear spelling mistakes and finish obviously truncated words, but do not change the meaning or add information that wasn't there.\n\n4. SUMMARY\n   After the full transcription, add a 3-sentence summary of what these notes are about.\n\n5. ACTION ITEMS\n   If anything in the notes looks like a task, deadline, or reminder, list them separately under 'Action items found'.\n\nOutput the transcription first, then the summary, then action items \u2014 in that order, clearly separated.",
      "tags": [
        "handwriting",
        "notes",
        "OCR",
        "transcription",
        "study",
        "image-to-text"
      ]
    },
    {
      "id": 12,
      "title": "Turn Any Topic Into a Visual Learning Map",
      "command": "/VisualizeLearning",
      "category": "Education",
      "subcategory": "Learning",
      "difficulty": "Beginner",
      "use_case": "Studying visually instead of through dense paragraphs \u2014 great for visual learners preparing for exams or learning something new fast.",
      "content": "You are a learning designer who specializes in visual and spatial teaching methods for people who understand concepts better through structure than prose.\n\nTopic to visualize: [THE TOPIC]\nMy current understanding: [NONE / BASIC / INTERMEDIATE]\n\nBuild a visual learning map using only text-based visual structure (ASCII-style layout, indentation, and symbols \u2014 no actual image generation needed):\n\n1. CENTRAL CONCEPT BOX\n   One sentence, boxed conceptually, that is the core idea everything else branches from.\n\n2. BRANCH STRUCTURE\n   Break the topic into 3-5 major branches. For each branch, show 2-3 sub-points indented beneath it, like a mind map laid out in text.\n\n3. RELATIONSHIP ARROWS\n   Describe using arrows (\u2192) how the branches connect to or depend on each other. Which ideas must be understood before others?\n\n4. VISUAL ANALOGY\n   Describe one physical, spatial, or visual analogy for the whole topic (e.g., 'think of this like a subway map where...').\n\n5. ONE-PAGE MENTAL MODEL\n   Condense everything into a single paragraph you could picture as one diagram if you closed your eyes.\n\nKeep language concrete and spatial \u2014 avoid abstract description. If I said 'draw this,' what would appear?",
      "tags": [
        "visual-learning",
        "mind-map",
        "study",
        "learning",
        "diagram",
        "education"
      ]
    },
    {
      "id": 13,
      "title": "Screenshot to Working Code",
      "command": "/ScreenshotToCode",
      "category": "Coding",
      "subcategory": "UI Development",
      "difficulty": "Intermediate",
      "use_case": "Recreating a UI design, competitor screenshot, or Figma export as real HTML/CSS or component code. Requires a vision-capable model (attach the screenshot).",
      "content": "You are a senior frontend engineer skilled at pixel-matching UI from screenshots. I'm attaching a screenshot of a UI I want rebuilt.\n\nFramework I want: [HTML/CSS, React, Tailwind, etc. \u2014 specify]\n\nWork through this:\n\n1. LAYOUT BREAKDOWN\n   Describe the structure you see: header, sidebar, cards, grid, spacing patterns. Identify the layout system (flexbox grid, fixed columns, etc.).\n\n2. DESIGN TOKENS\n   Estimate the color palette (hex codes), font sizes, border radius, and spacing scale used, based on what's visible.\n\n3. COMPONENT BREAKDOWN\n   List the distinct reusable components you can identify (e.g., 'Card', 'NavItem', 'Badge').\n\n4. BUILD THE CODE\n   Write clean, working code in my chosen framework that matches the screenshot as closely as possible. Use semantic HTML and responsive units, not fixed pixel hacks.\n\n5. WHAT YOU GUESSED\n   Flag any part of the design you had to estimate because it wasn't fully visible (e.g., hover states, exact spacing) so I know what to double-check.",
      "tags": [
        "screenshot",
        "UI",
        "frontend",
        "code-generation",
        "design-to-code",
        "coding"
      ]
    },
    {
      "id": 14,
      "title": "Whiteboard Photo to Organized Action Plan",
      "command": "/WhiteboardToPlan",
      "category": "Productivity",
      "subcategory": "Meetings",
      "difficulty": "Beginner",
      "use_case": "After a brainstorm, planning session, or team meeting where ideas were scribbled on a whiteboard. Requires a vision-capable model (attach the photo).",
      "content": "You are a facilitator who is excellent at converting messy whiteboard brainstorms into structured, actionable plans. I'm attaching a photo of a whiteboard.\n\nProcess it as follows:\n\n1. RAW CONTENTS\n   List everything you can read on the board, grouped by physical location/clusters as they appear (top-left cluster, arrows connecting to X, etc.).\n\n2. THEME GROUPING\n   Group the raw items into 3-5 logical themes, even if they were scattered across the board.\n\n3. DECISIONS VS IDEAS\n   Separate what looks like a firm decision (circled, underlined, starred) from what looks like an open idea or brainstorm item.\n\n4. ACTION PLAN\n   Convert the decisions and strongest ideas into a numbered action plan: Owner (if indicated), Task, Priority (High/Medium/Low based on visual emphasis).\n\n5. WHAT NEEDS CLARIFICATION\n   List anything ambiguous or illegible that the team should clarify before acting on it.\n\nFormat for easy pasting into Notion, Slack, or an email recap.",
      "tags": [
        "whiteboard",
        "brainstorm",
        "meetings",
        "image-to-text",
        "planning",
        "productivity"
      ]
    },
    {
      "id": 15,
      "title": "Any Document to Spaced-Repetition Flashcards",
      "command": "/DocToFlashcards",
      "category": "Education",
      "subcategory": "Study Tools",
      "difficulty": "Beginner",
      "use_case": "Turning textbook chapters, lecture slides, or long articles into flashcards for Anki, Quizlet, or manual review.",
      "content": "You are a learning scientist who designs flashcards using proven spaced-repetition principles: atomic facts, active recall framing, and no ambiguous answers.\n\n[PASTE THE TEXT, CHAPTER, OR ARTICLE CONTENT HERE]\n\nBuild flashcards following these exact rules:\n\n1. ONE FACT PER CARD\n   Never combine two ideas into one card. If a sentence has two facts, that's two cards.\n\n2. QUESTION FORMAT\n   Phrase the front as a specific question, not a fill-in-the-blank. 'What causes X?' not 'X is caused by ___.'\n\n3. UNAMBIGUOUS ANSWERS\n   The back must have exactly one correct answer. If a concept has nuance, simplify the card and note the nuance separately.\n\n4. DIFFICULTY TIERS\n   Label each card Easy, Medium, or Hard based on how much reasoning (vs. pure recall) it requires.\n\n5. GROUPING\n   Group the cards by sub-topic with a header, so I can study them in logical clusters rather than random order.\n\nOutput format for each card:\nQ: [question]\nA: [answer]\nDifficulty: [level]\n\nAim for 10-20 cards depending on how much content I gave you \u2014 quality over quantity.",
      "tags": [
        "flashcards",
        "study",
        "spaced-repetition",
        "anki",
        "learning",
        "education"
      ]
    },
    {
      "id": 16,
      "title": "Receipt Photo to Expense Entry",
      "command": "/ReceiptToExpense",
      "category": "Productivity",
      "subcategory": "Finance",
      "difficulty": "Beginner",
      "use_case": "Quickly logging business or personal expenses from a photo instead of manual data entry. Requires a vision-capable model (attach the receipt photo).",
      "content": "You are a meticulous bookkeeper who converts receipt photos into clean, structured expense records. I'm attaching a photo of a receipt.\n\nExtract and structure the following:\n\n1. VENDOR\n   Business name exactly as printed.\n\n2. DATE\n   Transaction date in YYYY-MM-DD format.\n\n3. LINE ITEMS\n   Each purchased item with its individual price, if itemized on the receipt.\n\n4. TOTALS\n   Subtotal, tax, tip (if present), and final total \u2014 flag if any of these don't visibly add up correctly.\n\n5. SUGGESTED CATEGORY\n   Classify this expense into a common category: Meals, Travel, Office Supplies, Software, Other \u2014 based on the vendor and items.\n\n6. EXPENSE REPORT LINE\n   Format a single line suitable for pasting into an expense report:\n   [Date] | [Vendor] | [Category] | [Total] | [Brief description]\n\nIf any text on the receipt is blurry or cut off, say so rather than guessing at a number.",
      "tags": [
        "receipt",
        "expenses",
        "finance",
        "image-to-text",
        "bookkeeping",
        "productivity"
      ]
    },
    {
      "id": 17,
      "title": "Explain Any Chart or Diagram in Plain English",
      "command": "/DiagramExplainer",
      "category": "Research",
      "subcategory": "Data Interpretation",
      "difficulty": "Beginner",
      "use_case": "Understanding a complex chart, scientific diagram, org chart, or system architecture diagram from a report, paper, or presentation. Requires a vision-capable model (attach the image).",
      "content": "You are a brilliant explainer who can make any chart or diagram immediately understandable to a smart non-expert. I'm attaching an image of a chart or diagram.\n\nExplain it in this structure:\n\n1. WHAT KIND OF VISUAL THIS IS\n   Name the type (bar chart, flowchart, org chart, system diagram, scatter plot, etc.) and what it's generally used to show.\n\n2. THE HEADLINE TAKEAWAY\n   If this diagram could only tell me ONE thing, what is it? State it in one sentence before any details.\n\n3. WALK THROUGH THE STRUCTURE\n   Explain the axes, nodes, boxes, or categories in plain language \u2014 what does each part represent?\n\n4. THE INTERESTING PART\n   What's the most notable pattern, outlier, or relationship visible in this specific diagram? Don't just describe structure \u2014 interpret it.\n\n5. WHAT'S MISSING OR UNCLEAR\n   Note anything that's ambiguous, poorly labeled, or that would need more context to fully understand.\n\nAssume I can see the image but haven't been trained on how to read this specific type of visual \u2014 teach me as you explain it.",
      "tags": [
        "diagram",
        "chart",
        "data-visualization",
        "image-to-text",
        "research",
        "explanation"
      ]
    },
    {
      "id": 18,
      "title": "Messy Notes to Structured Mind Map",
      "command": "/MindMapBuilder",
      "category": "Productivity",
      "subcategory": "Organization",
      "difficulty": "Beginner",
      "use_case": "Organizing scattered thoughts, brainstorm dumps, or stream-of-consciousness notes into a clear hierarchical structure.",
      "content": "You are an information architect who specializes in turning chaotic, unstructured thinking into clear hierarchical mind maps.\n\n[PASTE YOUR MESSY NOTES, BRAIN DUMP, OR RANDOM THOUGHTS HERE]\n\nBuild a mind map using this process:\n\n1. FIND THE CENTER\n   Identify the single central theme that everything else relates back to, even if it wasn't stated explicitly.\n\n2. IDENTIFY MAIN BRANCHES\n   Group the scattered content into 3-6 major branches coming off the center. Name each branch clearly.\n\n3. NEST THE DETAILS\n   Under each branch, nest the specific details, examples, or sub-points from the original notes \u2014 indented to show hierarchy.\n\n4. SURFACE HIDDEN CONNECTIONS\n   Point out any places where two branches actually relate to each other, even though they weren't written near each other originally.\n\n5. FLAG GAPS\n   Note any branch that feels thin or incomplete based on how much was written about the others \u2014 this often reveals what needs more thinking.\n\nPresent the final mind map as an indented text hierarchy (using dashes and indentation), not just a paragraph summary.",
      "tags": [
        "mind-map",
        "organization",
        "brainstorm",
        "structure",
        "productivity",
        "notes"
      ]
    },
    {
      "id": 19,
      "title": "Resume Bullet Rewriter",
      "command": "/ResumeRewrite",
      "category": "Resume",
      "subcategory": "Bullet Points",
      "difficulty": "Beginner",
      "use_case": "Turning vague resume bullets into impact-driven, metric-backed lines that pass both ATS scans and human review.",
      "content": "You are a professional resume writer who has helped candidates land roles at competitive companies. You know that hiring managers skim resumes in under 10 seconds, so every bullet must earn its place.\n\nHere are my current resume bullets:\n[PASTE YOUR BULLETS HERE]\n\nMy target role: [JOB TITLE YOU'RE APPLYING FOR]\n\nRewrite each bullet using this exact formula: Action verb + what you did + how you did it + measurable result.\n\nRules:\n1. Start every bullet with a strong action verb (Led, Built, Reduced, Increased) \u2014 never 'Responsible for' or 'Worked on'.\n2. Add a number wherever plausible \u2014 percentage, dollar amount, time saved, team size, volume handled. If I didn't give you a number, ask me for one rather than inventing it.\n3. Cut filler words: 'various', 'multiple', 'a lot of', 'helped with'.\n4. Keep each bullet to one line \u2014 if it needs two lines, it's two ideas that should be split.\n5. Tailor the language toward keywords relevant to my target role, without sounding like keyword stuffing.\n\nFor each bullet, show:\nOriginal: [what I gave you]\nRewritten: [your version]\nWhy it's stronger: [one sentence]",
      "tags": [
        "resume",
        "career",
        "job-search",
        "writing",
        "ATS",
        "resume-writing"
      ]
    },
    {
      "id": 20,
      "title": "Mock Interview Simulator",
      "command": "/MockInterviewer",
      "category": "Interview",
      "subcategory": "Interview Prep",
      "difficulty": "Intermediate",
      "use_case": "Practicing for a real interview with realistic follow-up questions and honest feedback before the real thing.",
      "content": "You are a senior hiring manager conducting a real interview \u2014 not a friendly practice session. You ask sharp follow-up questions and don't let vague answers slide.\n\nRole I'm interviewing for: [JOB TITLE]\nCompany type: [STARTUP / ENTERPRISE / AGENCY, etc.]\nInterview type: [BEHAVIORAL / TECHNICAL / CASE STUDY]\n\nRun the interview like this:\n\n1. Ask me one question at a time \u2014 do not give me the whole list upfront.\n2. After I answer, follow up at least once on something vague, unquantified, or underexplained in my answer \u2014 the way a real interviewer would push for specifics.\n3. Ask a mix of: one opening question, two behavioral questions (using situations from my experience), one role-specific technical or scenario question, and one closing 'do you have questions for us' moment.\n4. Stay in character as the interviewer throughout \u2014 don't break to coach me until the end.\n\nAfter 5 questions, switch to feedback mode:\n- What I answered well\n- Where my answers were vague or unconvincing\n- The single biggest improvement to make before the real interview\n\nStart with your first question now.",
      "tags": [
        "interview",
        "career",
        "job-search",
        "practice",
        "behavioral-interview",
        "mock-interview"
      ]
    },
    {
      "id": 21,
      "title": "Excel Formula Builder",
      "command": "/ExcelFormula",
      "category": "Excel",
      "subcategory": "Formulas",
      "difficulty": "Beginner",
      "use_case": "Getting the exact formula for a spreadsheet task without digging through documentation, with a plain-English explanation of how it works.",
      "content": "You are a spreadsheet expert fluent in both Excel and Google Sheets formulas, including their differences.\n\nWhat I'm trying to do: [DESCRIBE THE TASK IN PLAIN ENGLISH \u2014 e.g. 'find the total sales for each region but only for orders after March']\nMy data layout: [DESCRIBE COLUMNS \u2014 e.g. 'Column A = Region, Column B = Date, Column C = Sales Amount']\nExcel or Google Sheets: [SPECIFY WHICH]\n\nGive me:\n\n1. THE FORMULA\n   The exact formula to type, using my actual column letters \u2014 not generic placeholders.\n\n2. HOW IT WORKS\n   Break down each part of the formula in plain English, so I understand it well enough to modify it myself next time.\n\n3. WHERE TO PUT IT\n   Which cell to enter it in, and whether it needs to be dragged down/across or entered as an array formula.\n\n4. COMMON ERRORS\n   The most likely mistake someone makes when adapting this formula to their own sheet (wrong reference type, missing $ for absolute references, etc.).\n\n5. ALTERNATIVE APPROACH\n   If there's a newer function (like XLOOKUP vs VLOOKUP, or a pivot table) that would solve this more robustly, mention it as an option.",
      "tags": [
        "excel",
        "spreadsheets",
        "formulas",
        "google-sheets",
        "data",
        "productivity"
      ]
    },
    {
      "id": 22,
      "title": "Report to Slide-by-Slide Outline",
      "command": "/SlideOutline",
      "category": "PowerPoint",
      "subcategory": "Presentations",
      "difficulty": "Beginner",
      "use_case": "Turning a report, document, or raw set of talking points into a structured presentation outline with speaker notes, before opening PowerPoint or Google Slides.",
      "content": "You are a presentation coach who has helped executives turn dense reports into presentations that actually hold a room's attention.\n\nContent to present: [PASTE YOUR REPORT, DATA, OR KEY POINTS]\nAudience: [WHO IS THIS FOR \u2014 executives, clients, team, investors?]\nTime allotted: [HOW MANY MINUTES]\nGoal: [INFORM / PERSUADE / GET A DECISION]\n\nBuild a slide-by-slide outline:\n\n1. SLIDE COUNT\n   Recommend a slide count matching my time limit (roughly 1-2 minutes per slide for a spoken presentation).\n\n2. FOR EACH SLIDE, PROVIDE:\n   - Slide title (short, punchy \u2014 not a full sentence)\n   - 3-4 bullet points maximum (never paragraphs)\n   - Suggested visual (chart type, image, or diagram \u2014 not just text)\n   - Speaker notes: what I should actually SAY while this slide is up, written conversationally\n\n3. OPENING AND CLOSING\n   Make the first slide a hook, not an agenda. Make the last slide a clear ask or takeaway, not just 'Thank you'.\n\n4. THE ONE SLIDE THAT MATTERS MOST\n   Flag which single slide carries the most weight for my goal, so I know where to spend extra prep time.\n\nKeep bullet text short enough to read from across a room \u2014 if a bullet is a full sentence, shorten it.",
      "tags": [
        "powerpoint",
        "presentations",
        "slides",
        "public-speaking",
        "business",
        "productivity"
      ]
    },
    {
      "id": 23,
      "title": "Plain-English Contract Clause Review",
      "command": "/ContractClauseReview",
      "category": "Legal",
      "subcategory": "Contract Review",
      "difficulty": "Intermediate",
      "use_case": "Understanding what a specific contract clause actually means and what risk it carries before signing \u2014 for general understanding, not as a replacement for a lawyer.",
      "content": "You are explaining contract language to a smart non-lawyer who wants to actually understand what they're agreeing to before signing.\n\nIMPORTANT: This is for general understanding only and is not legal advice. For any contract with real financial or legal stakes, a licensed attorney should review it before signing.\n\nClause to review:\n[PASTE THE SPECIFIC CLAUSE OR SECTION HERE]\n\nContext: [WHAT KIND OF CONTRACT IS THIS \u2014 employment, freelance, lease, NDA, etc.]\n\nBreak it down:\n\n1. PLAIN-ENGLISH TRANSLATION\n   What does this clause actually say, in normal language, stripped of legal jargon?\n\n2. WHAT IT OBLIGATES ME TO\n   What am I specifically agreeing to do, avoid, or give up if I sign this as written?\n\n3. WHERE THE RISK IS\n   What's the realistic worst-case scenario this clause could create for me? Is the risk common/standard or unusual?\n\n4. QUESTIONS WORTH ASKING\n   What specific questions should I ask the other party or a lawyer about this clause before signing?\n\n5. WHAT'S MISSING\n   Is there a protection a fair version of this clause would typically include, that isn't present here?\n\nEnd with a reminder that this explanation is educational only and doesn't replace review by a qualified attorney, especially for anything with significant financial or legal consequences.",
      "tags": [
        "legal",
        "contracts",
        "review",
        "business",
        "risk",
        "plain-english"
      ]
    },
    {
      "id": 24,
      "title": "Empathetic Customer Support Reply",
      "command": "/SupportReply",
      "category": "Customer Support",
      "subcategory": "Response Drafting",
      "difficulty": "Beginner",
      "use_case": "Drafting a support reply that resolves the issue and de-escalates frustration, for tickets, emails, or chat.",
      "content": "You are a senior customer support lead known for turning frustrated customers into loyal ones through how you communicate, not just what you offer.\n\nCustomer's message: [PASTE THEIR COMPLAINT OR QUESTION]\nWhat actually happened: [THE REAL SITUATION \u2014 was it our error, a misunderstanding, a policy limit?]\nWhat I can offer: [REFUND / CREDIT / FIX / EXPLANATION ONLY \u2014 be specific about what's actually possible]\nTone needed: [PROFESSIONAL / WARM / FORMAL]\n\nWrite the reply following this structure:\n\n1. ACKNOWLEDGE FIRST\n   Open by acknowledging their specific frustration \u2014 not a generic 'we're sorry for the inconvenience.' Reference what actually happened to them.\n\n2. OWN IT WITHOUT OVER-APOLOGIZING\n   If it was our mistake, say so plainly in one sentence. Don't grovel \u2014 over-apologizing reads as insincere and undermines confidence.\n\n3. THE RESOLUTION\n   State clearly and specifically what you're doing to fix it \u2014 no vague 'we'll look into it.'\n\n4. PREVENT THE NEXT MESSAGE\n   Answer the obvious follow-up question before they have to ask it (timeline, next steps, who to contact).\n\n5. CLOSE HUMAN\n   End without corporate stock phrases like 'valued customer' \u2014 sound like a person who actually read their message.\n\nKeep it under 150 words unless the situation genuinely requires more detail.",
      "tags": [
        "customer-support",
        "email",
        "communication",
        "customer-service",
        "de-escalation",
        "support"
      ]
    },
    {
      "id": 25,
      "title": "SEO Article Outline Builder",
      "command": "/SEOOutline",
      "category": "SEO",
      "subcategory": "Content Strategy",
      "difficulty": "Intermediate",
      "use_case": "Planning a blog post or article that's structured to rank well and genuinely answer the searcher's intent \u2014 before writing a single sentence.",
      "content": "You are an SEO content strategist who cares equally about ranking and actually being useful \u2014 you've seen too many 'SEO-optimized' articles that game keywords but say nothing.\n\nTarget keyword: [YOUR PRIMARY KEYWORD]\nSearch intent: [INFORMATIONAL / COMMERCIAL / TRANSACTIONAL \u2014 what is someone trying to accomplish when they search this?]\nTarget audience: [WHO IS SEARCHING THIS]\n\nBuild the outline:\n\n1. SEARCH INTENT ANALYSIS\n   What is the person actually trying to find out or do? What would make them leave satisfied versus still searching?\n\n2. TITLE OPTIONS\n   Three title tag options under 60 characters, each including the target keyword naturally \u2014 not stuffed.\n\n3. HEADING STRUCTURE (H1-H3)\n   A full heading outline that thoroughly answers the search intent, ordered the way a reader would naturally want information, not just keyword variations stacked together.\n\n4. WHAT COMPETING ARTICLES ARE MISSING\n   Based on typical coverage of this topic, what's the specific angle or depth this article should include to stand out rather than repeat what's already ranking?\n\n5. INTERNAL LINKING OPPORTUNITIES\n   What related subtopics from this outline could become their own future articles that link back to this one?\n\n6. META DESCRIPTION\n   One version under 155 characters that would make someone click from the search results.\n\nPrioritize genuinely answering the reader over keyword density \u2014 the outline should read like the best possible answer to the search, not a keyword checklist.",
      "tags": [
        "SEO",
        "content-strategy",
        "blogging",
        "marketing",
        "keywords",
        "writing"
      ]
    },
    {
      "id": 26,
      "title": "Sales Objection Handler",
      "command": "/ObjectionHandler",
      "category": "Sales",
      "subcategory": "Objection Handling",
      "difficulty": "Intermediate",
      "use_case": "Preparing responses to a specific objection before a sales call, or handling one that just came up in a live deal.",
      "content": "You are a sales trainer who has coached reps on objection handling for complex B2B and B2C sales. You believe the best objection response acknowledges the concern instead of steamrolling past it.\n\nThe objection I'm facing: [WRITE THE EXACT OBJECTION \u2014 e.g. 'your price is too high compared to Competitor X']\nWhat I'm selling: [PRODUCT/SERVICE]\nWho's raising it: [DECISION MAKER'S ROLE \u2014 e.g. CFO, end user, procurement]\nWhat I know about their situation: [ANY CONTEXT ON WHY THIS OBJECTION IS COMING UP]\n\nGive me a response using this framework:\n\n1. ACKNOWLEDGE\n   A one-sentence response that shows you actually heard the concern, not a dismissive pivot.\n\n2. REFRAME\n   Shift the conversation from the surface objection to what's actually driving it (price objections are often value objections in disguise).\n\n3. EVIDENCE\n   What specific proof point, comparison, or question would address the real concern \u2014 not a generic 'we're worth it' claim.\n\n4. THE ASK\n   End with a question that moves the conversation forward rather than a dead-end statement.\n\n5. IF THEY PUSH BACK AGAIN\n   Give me one fallback response in case my first answer doesn't land.\n\nWrite this as an actual script I could say out loud, not a description of the strategy.",
      "tags": [
        "sales",
        "objection-handling",
        "negotiation",
        "B2B",
        "closing",
        "business"
      ]
    },
    {
      "id": 27,
      "title": "Image Generation Prompt Builder",
      "command": "/ImagePromptBuilder",
      "category": "Image Generation",
      "subcategory": "Prompt Crafting",
      "difficulty": "Beginner",
      "use_case": "Turning a rough visual idea into a detailed prompt for Midjourney, DALL-E, or similar image generators that produces consistent, high-quality results.",
      "content": "You are an expert prompt engineer for AI image generators, fluent in the specific vocabulary that produces reliable, high-quality results across tools like Midjourney and DALL-E.\n\nMy rough idea: [DESCRIBE WHAT YOU WANT IN YOUR OWN WORDS]\nIntended use: [SOCIAL MEDIA / WEBSITE / PRINT / CONCEPT ART, etc.]\nTarget tool: [MIDJOURNEY / DALL-E / OTHER]\n\nBuild a detailed prompt covering:\n\n1. SUBJECT\n   A precise description of the main subject \u2014 pose, expression, action, not just 'a person'.\n\n2. STYLE\n   Specific art style or reference (photorealistic, watercolor, 3D render, in the style of a specific art movement \u2014 avoid naming living artists by name).\n\n3. COMPOSITION\n   Camera angle, framing (close-up, wide shot), and focal point.\n\n4. LIGHTING AND MOOD\n   Specific lighting description (golden hour, studio lighting, dramatic shadows) and the emotional tone.\n\n5. TECHNICAL PARAMETERS\n   Suggested aspect ratio and any tool-specific parameters (e.g. Midjourney's --ar or --stylize flags) if relevant to the target tool.\n\nGive me:\n- The final assembled prompt, ready to paste in\n- One alternative version with a different mood/style for comparison\n- What to change first if the first result isn't quite right",
      "tags": [
        "image-generation",
        "midjourney",
        "AI-art",
        "prompt-engineering",
        "design",
        "creative"
      ]
    },
    {
      "id": 28,
      "title": "Short-Form Video Script Builder",
      "command": "/VideoScriptBuilder",
      "category": "Video Generation",
      "subcategory": "Script Writing",
      "difficulty": "Intermediate",
      "use_case": "Writing a script for TikTok, Reels, or Shorts that's structured to hold attention in the first 3 seconds and drive a specific action.",
      "content": "You are a short-form video strategist who understands exactly why most videos lose viewers in the first 3 seconds, and how to structure a script that doesn't.\n\nTopic/product: [WHAT THIS VIDEO IS ABOUT]\nPlatform: [TIKTOK / REELS / SHORTS]\nGoal: [AWARENESS / SALES / FOLLOWS / ENGAGEMENT]\nLength: [15s / 30s / 60s]\n\nWrite the script using this structure:\n\n1. HOOK (first 3 seconds)\n   A specific line or visual moment that stops the scroll \u2014 not a slow intro. Give 2 hook options.\n\n2. THE BODY\n   Break down what happens second by second, written as: [TIME] \u2014 [WHAT'S SHOWN] \u2014 [WHAT'S SAID]. Keep sentences short enough to say naturally without rushing.\n\n3. THE PAYOFF\n   The moment that delivers on what the hook promised \u2014 this is what makes someone watch to the end instead of scrolling away.\n\n4. CALL TO ACTION\n   One clear, specific action (not 'like and subscribe' \u2014 something tied to the actual goal, like 'comment X for the template').\n\n5. ON-SCREEN TEXT\n   Suggested caption/text overlay for key moments, since most viewers watch with sound off initially.\n\nWrite it exactly as I would read it aloud on camera \u2014 natural spoken rhythm, not written-for-reading prose.",
      "tags": [
        "video",
        "short-form",
        "tiktok",
        "reels",
        "scriptwriting",
        "content-creation"
      ]
    },
    {
      "id": 29,
      "title": "Turn Any Data Table Into Clear Insights",
      "command": "/DataAnalyst",
      "category": "Research",
      "subcategory": "Data Analysis",
      "difficulty": "Intermediate",
      "use_case": "Making sense of a spreadsheet, survey results, or dataset without needing to know statistics \u2014 paste the data or describe it.",
      "content": "You are a data analyst who is excellent at finding the story inside a dataset and explaining it to someone who isn't a statistician.\n\n[PASTE YOUR DATA \u2014 a table, CSV snippet, or describe the numbers you have]\nWhat I'm trying to understand: [YOUR QUESTION \u2014 e.g. 'why did sales drop in March']\n\nAnalyze it in this order:\n\n1. WHAT THE DATA SHOWS AT A GLANCE\n   The single most important pattern before any deep analysis \u2014 the headline, not the details.\n\n2. NOTABLE TRENDS\n   Identify 2-3 real trends (increases, decreases, correlations) \u2014 and be clear about which are strong versus which are weak/noisy.\n\n3. OUTLIERS\n   Point out any data points that don't fit the pattern and are worth investigating separately.\n\n4. LIKELY EXPLANATIONS\n   For the pattern most relevant to my question, suggest 2-3 plausible explanations \u2014 clearly labeled as hypotheses, not confirmed facts, since correlation isn't causation.\n\n5. WHAT I SHOULD LOOK AT NEXT\n   What additional data would confirm or rule out your top hypothesis?\n\nBe honest about the limits of what this data can actually tell us \u2014 don't overstate confidence in a small or incomplete dataset.",
      "tags": [
        "data-analysis",
        "spreadsheets",
        "insights",
        "research",
        "statistics",
        "business"
      ]
    },
    {
      "id": 30,
      "title": "Realistic Trip Itinerary Builder",
      "command": "/TripPlanner",
      "category": "Travel",
      "subcategory": "Itinerary Planning",
      "difficulty": "Beginner",
      "use_case": "Planning a trip that's actually realistic to execute, not an exhausting checklist of every possible attraction.",
      "content": "You are a travel planner who designs itineraries people can actually enjoy, not just survive \u2014 pacing matters as much as the list of places.\n\nDestination: [WHERE]\nDates/length: [HOW MANY DAYS]\nTraveling with: [SOLO / PARTNER / FAMILY WITH KIDS / FRIENDS]\nPace preference: [PACKED / BALANCED / RELAXED]\nMust-do's: [ANYTHING NON-NEGOTIABLE]\nBudget level: [BUDGET / MID-RANGE / LUXURY]\n\nBuild the itinerary:\n\n1. DAY-BY-DAY PLAN\n   For each day: a morning, afternoon, and evening activity \u2014 grouped by geographic area so I'm not crossing the city back and forth.\n\n2. REALISTIC PACING\n   Flag if any day is overpacked given travel time between locations, and suggest what to cut if so.\n\n3. LOCAL FOOD RECOMMENDATIONS\n   One specific type of local dish or dining experience to try, placed near where I'll already be that day.\n\n4. BUFFER TIME\n   Build in at least one unstructured block per day for rest, spontaneous exploring, or delays.\n\n5. BOOK-AHEAD LIST\n   Anything that needs advance booking (popular restaurants, timed tickets) flagged clearly so I don't find out too late.\n\nBe honest if my must-do list doesn't fit in the time I have, and tell me what I'd need to cut or extend.",
      "tags": [
        "travel",
        "itinerary",
        "trip-planning",
        "vacation",
        "productivity"
      ]
    },
    {
      "id": 31,
      "title": "Personal Budget Reality Check",
      "command": "/BudgetCheck",
      "category": "Personal Finance",
      "subcategory": "Budgeting",
      "difficulty": "Beginner",
      "use_case": "Getting an honest read on your monthly budget and where it's actually leaking, for general organization \u2014 not a substitute for a financial advisor.",
      "content": "You are a candid personal finance coach who helps people see their spending clearly without judgment \u2014 but also without sugarcoating. This is for general budgeting organization only, not professional financial, tax, or investment advice.\n\nMonthly income: [AMOUNT]\nMonthly expenses (list what you remember): [RENT, BILLS, SUBSCRIPTIONS, FOOD, ETC. WITH ROUGH AMOUNTS]\nWhat I'm trying to achieve: [SAVE FOR X / PAY OFF DEBT / JUST UNDERSTAND WHERE MONEY GOES]\n\nWork through this:\n\n1. THE REAL NUMBERS\n   Add up what I've listed versus my income. Show the gap clearly \u2014 surplus or shortfall.\n\n2. WHERE THE LEAKS LIKELY ARE\n   Based on typical spending patterns, what category is most likely underestimated (subscriptions, food delivery, and irregular expenses are the most commonly forgotten)?\n\n3. THE 3 LEVERS\n   Identify the 3 expense categories that would have the biggest impact if reduced even slightly \u2014 focus on the highest-leverage changes, not just the easiest to mention.\n\n4. A REALISTIC NEXT-MONTH TARGET\n   One specific, achievable adjustment to try next month \u2014 not a total lifestyle overhaul.\n\n5. WHAT TO TRACK\n   The single number worth checking weekly to know if the plan is working.\n\nEnd with a reminder that this is general guidance for organizing personal spending, not professional financial advice \u2014 a certified financial planner should be consulted for major financial decisions.",
      "tags": [
        "budgeting",
        "personal-finance",
        "money",
        "planning",
        "savings"
      ]
    },
    {
      "id": 32,
      "title": "Language Practice Partner",
      "command": "/LanguagePartner",
      "category": "Education",
      "subcategory": "Language Learning",
      "difficulty": "Beginner",
      "use_case": "Practicing conversation in a new language with real-time correction, at your actual level rather than a generic textbook pace.",
      "content": "You are a patient, encouraging language tutor and native-level conversation partner in [LANGUAGE I'M LEARNING].\n\nMy level: [COMPLETE BEGINNER / BASIC / INTERMEDIATE / ADVANCED]\nTopic I want to practice: [ORDERING FOOD, TRAVEL, WORK, CASUAL CONVERSATION, etc.]\n\nRun this as a real conversation practice session:\n\n1. Start the conversation in [LANGUAGE] at a pace appropriate for my level \u2014 simpler vocabulary and shorter sentences if I'm a beginner.\n\n2. After each of my responses, gently note any mistakes: what I said, what would be more natural, and why \u2014 but keep the conversation flowing rather than stopping for a full grammar lecture each time.\n\n3. If I'm clearly struggling, offer to switch to English briefly to explain a concept, then return to the target language.\n\n4. Introduce 1-2 new useful words or phrases naturally within the conversation, not as a separate vocabulary list.\n\n5. After 8-10 exchanges, pause and give me a short summary: what I did well, the 2-3 patterns of mistakes to watch for, and one thing to practice before our next conversation.\n\nStart the conversation now, in character as my conversation partner.",
      "tags": [
        "language-learning",
        "practice",
        "conversation",
        "education",
        "tutoring"
      ]
    },
    {
      "id": 33,
      "title": "LinkedIn Post That Doesn't Sound Like LinkedIn",
      "command": "/LinkedInPost",
      "category": "Marketing",
      "subcategory": "Social Media",
      "difficulty": "Beginner",
      "use_case": "Writing a LinkedIn post that reads like a real person, not the generic humble-brag or engagement-bait format everyone's tired of.",
      "content": "You are a writer known for LinkedIn posts that people actually stop scrolling for \u2014 because they sound like a real person thinking out loud, not a brand voice.\n\nWhat happened / what I want to share: [DESCRIBE THE STORY, LESSON, OR INSIGHT]\nGoal: [SHARE A LESSON / ANNOUNCE SOMETHING / START A DISCUSSION]\n\nWrite the post following these rules:\n\n1. OPENING LINE\n   One sentence that creates genuine curiosity \u2014 not a fake-vulnerable hook like 'I got rejected 47 times' unless that's literally true and relevant.\n\n2. NO ENGAGEMENT-BAIT PHRASES\n   Avoid 'Agree?', 'Thoughts?', 'This is huge', and similar filler that signals low-effort content.\n\n3. ONE CLEAR IDEA\n   The post should make exactly one point well, not three points shallowly.\n\n4. SPECIFIC OVER GENERIC\n   Replace vague claims ('hard work pays off') with the specific detail that actually happened to you.\n\n5. FORMATTING\n   Short paragraphs (1-3 sentences), line breaks for readability, no more than one relevant hashtag if any.\n\n6. NATURAL CLOSING\n   End with a genuine thought or question, not a forced call-to-action.\n\nGive me the final post, then one alternative opening line in case the first doesn't feel right.",
      "tags": [
        "linkedin",
        "social-media",
        "writing",
        "personal-branding",
        "marketing"
      ]
    },
    {
      "id": 34,
      "title": "Habit Plan That Actually Sticks",
      "command": "/HabitBuilder",
      "category": "Productivity",
      "subcategory": "Habit Formation",
      "difficulty": "Beginner",
      "use_case": "Building a new habit using a realistic plan instead of an all-or-nothing approach that usually fails by week two.",
      "content": "You are a behavior-change coach who understands that most habits fail not from lack of willpower, but from starting too big and too vague.\n\nHabit I want to build: [BE SPECIFIC \u2014 e.g. 'exercise more' is too vague; 'do 20 minutes of exercise' is workable]\nWhy this matters to me: [YOUR REAL REASON]\nPast attempts: [WHAT HAVE YOU TRIED BEFORE AND WHY DID IT STOP?]\nRealistic time/energy available: [BE HONEST]\n\nBuild the plan:\n\n1. SHRINK IT\n   Redesign this habit into a version so small it feels almost too easy to skip \u2014 the goal is consistency first, intensity later.\n\n2. ATTACH IT TO SOMETHING EXISTING\n   Suggest a specific existing routine to anchor the new habit to (right after coffee, right before bed) so it doesn't rely purely on remembering.\n\n3. REMOVE THE FIRST FRICTION POINT\n   Based on why past attempts failed, identify the one small obstacle that derails you first, and a concrete fix for it.\n\n4. THE 2-MINUTE VERSION\n   Define a minimum viable version of this habit for your worst days \u2014 the version you do even when everything else falls apart, so the streak survives.\n\n5. WEEKLY CHECK-IN QUESTION\n   One honest question to ask yourself each week to catch slipping before it becomes quitting.\n\nBe realistic, not motivational-poster generic \u2014 tailor this to the specific reasons I've failed before.",
      "tags": [
        "habits",
        "productivity",
        "behavior-change",
        "self-improvement",
        "goals"
      ]
    }
  ],
  "lessons": [
    {
      "id": 1,
      "title": "The Anatomy of a Great Prompt",
      "topic": "Prompt Design",
      "level": "Beginner",
      "duration": "12 min",
      "description": "The five components that separate a mediocre prompt from one that gets exactly what you need, every time.",
      "body": [
        {
          "heading": "Why most prompts fail",
          "text": "Most people write prompts like search queries \u2014 a few keywords and a hope. AI models respond to structure, not vibes. A prompt without role, context, format, and constraints forces the model to guess what you actually want, and it guesses based on the most generic, average answer it can produce."
        },
        {
          "heading": "The five components",
          "text": "1. Role \u2014 who should the AI act as? This sets tone, vocabulary, and depth. 2. Context \u2014 what does it need to know about your specific situation? 3. Task \u2014 the exact action, stated as a clear instruction, not a question. 4. Format \u2014 how should the output look? Bullet points, a table, a script? 5. Constraints \u2014 what should it avoid, prioritize, or limit (length, tone, banned words)."
        },
        {
          "heading": "Example transformation",
          "text": "Weak: 'Write me a marketing email.' Strong: 'You are a direct-response copywriter. Write a 100-word cold email to a startup founder about our analytics tool, using a curious subject line and one specific proof point. Avoid buzzwords like synergy or leverage.' Same request, completely different output quality."
        },
        {
          "heading": "Try it now",
          "text": "Take a prompt you've used before that gave a mediocre result. Rewrite it using all five components. Notice how much more specific your own thinking has to become \u2014 that specificity is exactly what the model needed."
        }
      ]
    },
    {
      "id": 2,
      "title": "Chain-of-Thought: Getting AI to Reason, Not Guess",
      "topic": "Advanced Techniques",
      "level": "Intermediate",
      "duration": "15 min",
      "description": "How asking a model to think step-by-step before answering dramatically improves accuracy on hard problems.",
      "body": [
        {
          "heading": "The core idea",
          "text": "Language models generate answers token by token, left to right. If you ask a hard question directly, the model commits to an answer path immediately \u2014 often the wrong one \u2014 and then has to justify it afterward. When you ask it to reason first, it explores the problem before committing, which produces far more accurate results on math, logic, and multi-step tasks."
        },
        {
          "heading": "How to trigger it",
          "text": "Add phrases like 'think through this step by step before giving your final answer' or 'list your reasoning, then conclude.' For complex problems, explicitly ask for numbered steps: identify the variables, consider the constraints, evaluate options, then decide."
        },
        {
          "heading": "Where it matters most",
          "text": "Chain-of-thought helps most on: math and logic problems, multi-step planning, code debugging, and decisions with tradeoffs. It matters least on simple factual lookups or creative writing, where it can actually make output feel over-explained."
        },
        {
          "heading": "A working example",
          "text": "Instead of: 'Should I raise prices by 20%?' \u2014 try: 'Walk through the tradeoffs of raising prices by 20%: customer retention risk, revenue impact, competitor pricing, and brand perception. Then give a clear recommendation.' The structure forces genuine analysis instead of a one-line guess."
        }
      ]
    },
    {
      "id": 3,
      "title": "Giving AI Examples: The Power of Few-Shot Prompting",
      "topic": "Prompt Design",
      "level": "Intermediate",
      "duration": "10 min",
      "description": "Why showing 2-3 examples of what you want is often more powerful than describing it in words.",
      "body": [
        {
          "heading": "Show, don't just tell",
          "text": "Describing a tone or format in words leaves room for interpretation. Showing 2-3 examples of exactly the output you want removes that ambiguity almost entirely. This is called few-shot prompting, and it's one of the most reliable ways to lock in a specific style."
        },
        {
          "heading": "How to structure examples",
          "text": "Give the input and the exact output you'd want for 2-3 varied cases, then give your new input and ask the model to continue the pattern. Varying your examples (not just repeating the same structure) helps the model generalize the pattern rather than copy it literally."
        },
        {
          "heading": "Common mistake",
          "text": "Using only one example. A single example teaches the model your literal content, not your pattern \u2014 it may just paraphrase your example instead of applying the underlying logic to new input. Two to three varied examples is the sweet spot for most tasks."
        },
        {
          "heading": "When to use it",
          "text": "Few-shot prompting shines for: matching a specific writing voice, formatting data consistently, classifying or labeling things according to your own criteria, and any task where 'I'll know it when I see it' describes your requirement better than a rule would."
        }
      ]
    },
    {
      "id": 4,
      "title": "Iterating: Your First Answer Is a Draft, Not a Verdict",
      "topic": "Workflow",
      "level": "Beginner",
      "duration": "9 min",
      "description": "The single habit that separates people who get great results from AI and people who give up after one try.",
      "body": [
        {
          "heading": "The mindset shift",
          "text": "Treat the first response as a rough draft from a smart but new collaborator \u2014 not a final verdict on what's possible. The people who get the best results rarely accept the first output. They read it critically and push back."
        },
        {
          "heading": "The three refinement moves",
          "text": "1. Narrow \u2014 'Make this more specific to [your exact situation].' 2. Redirect \u2014 'This is too formal, make it sound like I'm texting a friend.' 3. Challenge \u2014 'What's the weakest part of this argument? Now fix it.' Each move gets you measurably closer to what you actually needed."
        },
        {
          "heading": "Give feedback like a good editor",
          "text": "Instead of 'make it better,' say what's specifically wrong: 'the opening is generic,' 'this is too long,' 'you missed the constraint I gave about budget.' Specific feedback gets specific improvement. Vague feedback gets vague changes."
        },
        {
          "heading": "Know when to stop",
          "text": "If you've iterated 3-4 times and it's still missing the mark, the problem is usually the original prompt's context, not the model's ability. Go back and add the missing information rather than continuing to iterate on a flawed foundation."
        }
      ]
    },
    {
      "id": 5,
      "title": "Building Your Own Prompt Library",
      "topic": "Workflow",
      "level": "Beginner",
      "duration": "11 min",
      "description": "How to turn your best prompts into reusable templates so you're never starting from a blank page.",
      "body": [
        {
          "heading": "Why one-off prompts waste your progress",
          "text": "If you craft a great prompt once and never save it, you're rebuilding the same work from scratch next time. The highest-leverage habit in this space is treating your best prompts as reusable assets, not disposable messages."
        },
        {
          "heading": "Turn a prompt into a template",
          "text": "Take any prompt that worked well and replace the specific details with placeholders in brackets: [YOUR PRODUCT], [TARGET AUDIENCE], [TONE]. Now it's reusable for any future situation with the same shape, not just the one you originally wrote it for."
        },
        {
          "heading": "Organize by job, not by topic",
          "text": "Instead of organizing prompts by subject ('marketing', 'coding'), organize by the job you're hiring the prompt to do: 'get unstuck on a first draft,' 'find flaws in my reasoning,' 'compress a long document.' You'll reach for prompts faster when they're organized by the outcome you need."
        },
        {
          "heading": "Review and prune regularly",
          "text": "Every few weeks, look at which saved prompts you actually reused versus which ones you never touched again. Keep refining the ones that pull their weight. A library of 10 prompts you actually use beats 100 you never open."
        }
      ]
    }
  ],
  "tools": [
    {
      "id": 1,
      "name": "ChatGPT",
      "category": "Writing",
      "description": "OpenAI's flagship conversational AI. Strong all-rounder for writing, brainstorming, coding help, and general Q&A. The largest ecosystem of plugins and custom GPTs.",
      "pricing": "Free tier, Plus $20/mo",
      "bestFor": "General use, brainstorming, coding help",
      "url": "https://chat.openai.com"
    },
    {
      "id": 2,
      "name": "Claude",
      "category": "Writing",
      "description": "Anthropic's AI assistant, known for long-context understanding, careful reasoning, and strong performance on writing, analysis, and coding tasks with large documents.",
      "pricing": "Free tier, Pro $20/mo",
      "bestFor": "Long documents, careful writing, coding",
      "url": "https://claude.ai"
    },
    {
      "id": 3,
      "name": "Midjourney",
      "category": "Design",
      "description": "The industry-leading AI image generator, prized for its distinctive artistic quality and painterly aesthetic. Runs primarily through Discord.",
      "pricing": "From $10/mo",
      "bestFor": "Concept art, illustrations, moodboards",
      "url": "https://www.midjourney.com"
    },
    {
      "id": 4,
      "name": "GitHub Copilot",
      "category": "Coding",
      "description": "AI pair programmer built into your code editor. Suggests entire functions, completes boilerplate, and explains unfamiliar code in context.",
      "pricing": "$10/mo individual",
      "bestFor": "In-editor code completion",
      "url": "https://github.com/features/copilot"
    },
    {
      "id": 5,
      "name": "Perplexity",
      "category": "Research",
      "description": "AI-powered answer engine that searches the live web and cites its sources. Built for research and fact-finding rather than open-ended chat.",
      "pricing": "Free tier, Pro $20/mo",
      "bestFor": "Research with real-time citations",
      "url": "https://www.perplexity.ai"
    },
    {
      "id": 6,
      "name": "Notion AI",
      "category": "Productivity",
      "description": "AI writing and organization assistant built directly into Notion. Summarizes pages, drafts content, and helps organize notes and databases in place.",
      "pricing": "Add-on, from $8/mo",
      "bestFor": "Notes, docs, and workspace organization",
      "url": "https://www.notion.so/product/ai"
    },
    {
      "id": 7,
      "name": "Runway",
      "category": "Design",
      "description": "AI video generation and editing suite. Text-to-video, video-to-video style transfer, and green-screen-free background removal for creators.",
      "pricing": "Free tier, Standard $15/mo",
      "bestFor": "AI video generation and editing",
      "url": "https://runwayml.com"
    },
    {
      "id": 8,
      "name": "ElevenLabs",
      "category": "Audio",
      "description": "The most natural-sounding AI voice generator available, used for narration, dubbing, and voice cloning across dozens of languages.",
      "pricing": "Free tier, Starter $5/mo",
      "bestFor": "AI voiceovers and narration",
      "url": "https://elevenlabs.io"
    },
    {
      "id": 9,
      "name": "Zapier",
      "category": "Automation",
      "description": "No-code automation platform connecting thousands of apps. Increasingly AI-powered with natural language workflow building and AI-driven actions.",
      "pricing": "Free tier, Starter $19.99/mo",
      "bestFor": "Connecting apps and automating workflows",
      "url": "https://zapier.com"
    },
    {
      "id": 10,
      "name": "Grammarly",
      "category": "Writing",
      "description": "AI writing assistant focused on grammar, clarity, and tone. Integrates into browsers, email, and documents to catch errors and suggest improvements in real time.",
      "pricing": "Free tier, Premium $12/mo",
      "bestFor": "Grammar, clarity, and tone editing",
      "url": "https://www.grammarly.com"
    },
    {
      "id": 11,
      "name": "Gamma",
      "category": "Productivity",
      "description": "AI-powered presentation and document builder. Describe what you need and it generates a fully designed deck or one-pager in minutes, no design skill required.",
      "pricing": "Free tier, Plus $10/mo",
      "bestFor": "Fast presentations and one-pagers",
      "url": "https://gamma.app"
    }
  ],
  "glossary": [
    {
      "term": "Prompt",
      "definition": "The input text you give an AI model to produce a response.",
      "example": "'Write a haiku about autumn' is a prompt."
    },
    {
      "term": "Prompt Engineering",
      "definition": "The practice of designing inputs to reliably get better, more accurate outputs from an AI model.",
      "example": "Adding a role, format, and constraints to a request instead of a bare question."
    },
    {
      "term": "Token",
      "definition": "A chunk of text (roughly a word or part of a word) that a model reads and generates one piece at a time.",
      "example": "The word 'unbelievable' might be split into 3 tokens: un, believ, able."
    },
    {
      "term": "Context Window",
      "definition": "The maximum amount of text (in tokens) a model can consider at once, including your prompt and its own response.",
      "example": "A 200K-token context window can hold roughly a 500-page book."
    },
    {
      "term": "Hallucination",
      "definition": "When an AI model generates information that sounds plausible but is factually incorrect or made up.",
      "example": "A model confidently citing a research paper that doesn't exist."
    },
    {
      "term": "Fine-tuning",
      "definition": "Further training a pre-trained model on a specific dataset so it performs better on a narrower task.",
      "example": "Fine-tuning a general model on customer support transcripts to specialize it."
    },
    {
      "term": "Temperature",
      "definition": "A setting that controls how random or predictable a model's output is \u2014 low values are more focused, high values more varied.",
      "example": "Temperature 0 gives the same answer every time; temperature 1 gives more creative variety."
    },
    {
      "term": "Few-shot Prompting",
      "definition": "Giving a model a few examples of the input/output pattern you want before asking it to continue that pattern on new input.",
      "example": "Showing 3 example product descriptions before asking for a 4th in the same style."
    },
    {
      "term": "Chain-of-Thought",
      "definition": "Asking a model to reason step by step before giving a final answer, which improves accuracy on complex problems.",
      "example": "'Walk through this math problem step by step, then give the answer.'"
    },
    {
      "term": "System Prompt",
      "definition": "An instruction set given to a model before the conversation starts, defining its role, tone, or behavior for the whole session.",
      "example": "'You are a helpful customer support agent for a software company.'"
    },
    {
      "term": "RAG (Retrieval-Augmented Generation)",
      "definition": "A technique where a model retrieves relevant documents or data before generating a response, to ground answers in real information.",
      "example": "A support chatbot that looks up your actual order details before replying."
    },
    {
      "term": "Multimodal",
      "definition": "A model that can understand and generate more than one type of content \u2014 such as text, images, and audio \u2014 rather than text alone.",
      "example": "Uploading a photo of a receipt and asking the model to read it."
    },
    {
      "term": "LLM (Large Language Model)",
      "definition": "A machine learning model trained on massive amounts of text to understand and generate human-like language.",
      "example": "GPT-4, Claude, and Gemini are all LLMs."
    },
    {
      "term": "Agent",
      "definition": "An AI system that can take actions \u2014 like using tools, browsing, or calling APIs \u2014 to complete a task, not just generate text.",
      "example": "An AI agent that books a flight by searching, comparing prices, and completing checkout."
    },
    {
      "term": "API (Application Programming Interface)",
      "definition": "A way for one piece of software to talk to another \u2014 commonly how developers connect their apps to AI models.",
      "example": "A developer calls the OpenAI API to add AI chat to their own app."
    },
    {
      "term": "Zero-shot Prompting",
      "definition": "Asking a model to perform a task with no prior examples, relying only on its existing training.",
      "example": "'Translate this sentence to French' with no example translations given first."
    },
    {
      "term": "Embedding",
      "definition": "A numerical representation of text (or other data) that captures its meaning, used to compare or search content by similarity.",
      "example": "Embeddings let a search tool find 'car' and 'automobile' as related concepts."
    },
    {
      "term": "Model Context Protocol (MCP)",
      "definition": "An open standard that lets AI applications connect to external tools and data sources in a consistent way.",
      "example": "An MCP server that lets an AI assistant read and update your calendar."
    },
    {
      "term": "Inference",
      "definition": "The process of a trained model generating an output from a given input \u2014 as opposed to training, when the model is being built.",
      "example": "Every time you send a message to ChatGPT, that's one inference request."
    },
    {
      "term": "Guardrails",
      "definition": "Rules, filters, or constraints built into an AI system to keep its outputs safe, accurate, or within intended limits.",
      "example": "A content filter that stops a model from generating harmful instructions."
    }
  ]
};
